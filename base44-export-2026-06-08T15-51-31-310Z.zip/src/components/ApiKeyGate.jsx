// ApiKeyGate no longer blocks the app — it just renders children always.
// Use useApiKey() in tool pages to check if authedKey exists before running actions.
export default function ApiKeyGate({ children }) {
  return children;
}