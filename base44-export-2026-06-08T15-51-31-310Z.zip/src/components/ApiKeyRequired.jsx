import { useApiKey } from "@/lib/ApiKeyContext";
import { KeyRound, Lock } from "lucide-react";

/**
 * Wrap the actionable part of a tool page.
 * If no API key → shows a soft locked overlay instead.
 */
export default function ApiKeyRequired({ children }) {
  const { authedKey } = useApiKey();

  if (authedKey) return children;

  return (
    <div className="relative">
      {/* Blurred content */}
      <div className="pointer-events-none select-none opacity-30 blur-sm">
        {children}
      </div>
      {/* Overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
        <div className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-border shadow-xl px-8 py-6 text-center max-w-xs">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center mx-auto mb-3">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <p className="font-semibold text-foreground text-sm mb-1">API Key Required</p>
          <p className="text-xs text-muted-foreground">Enter your API key using the banner at the top to unlock this tool.</p>
        </div>
      </div>
    </div>
  );
}