import { Link } from "react-router-dom";
import { ArrowLeft, Zap, Globe, Monitor, Image, Video, Mail, Mic, Code2, BarChart2, Music, QrCode, FileText, FileDown, ClipboardList, MessageSquare, LayoutDashboard, KeyRound, FlaskConical, BookOpen } from "lucide-react";

const ICON_MAP = {
  LayoutDashboard,
  Globe,
  Monitor,
  Image,
  Video,
  Mail,
  Mic,
  Code2,
  BarChart2,
  Zap,
  Music,
  QrCode,
  FileText,
  FileDown,
  ClipboardList,
  MessageSquare,
  KeyRound,
  FlaskConical,
  BookOpen,
};

export default function ToolHeader({ tool }) {
  const Icon = ICON_MAP[tool.icon];

  return (
    <div className="flex items-center justify-between px-6 py-4 bg-white dark:bg-slate-900 border-b border-border">
      <div className="flex items-center gap-3">
        <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center`}>
          {Icon && <Icon className="w-4 h-4 text-white" />}
        </div>
        <div>
          <h1 className="font-semibold text-foreground text-base leading-none">{tool.label}</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{tool.description}</p>
        </div>
      </div>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Zap className="w-3 h-3 text-violet-500" />
        Powered by AI
      </div>
    </div>
  );
}