import { Link, useLocation } from "react-router-dom";
import { TOOLS } from "@/lib/tools";
import { Moon, Sun, Sparkles, LayoutDashboard, Globe, Monitor, Image, Video, Mail, Mic, Code2, BarChart2, Zap, Music, QrCode, FileText, FileDown, ClipboardList, MessageSquare, FolderOpen, KeyRound, FlaskConical, LogOut, BookOpen } from "lucide-react";
import { useApiKey } from "@/lib/ApiKeyContext";

const ICON_MAP = {
  LayoutDashboard,
  Globe,
  Monitor,
  Image,
  Video,
  Mail,
  Mic,
  Code2,
  BarChart2,
  Zap,
  Music,
  QrCode,
  FileText,
  FileDown,
  ClipboardList,
  MessageSquare,
  KeyRound,
  FlaskConical,
  BookOpen,
};

export default function Sidebar({ darkMode, setDarkMode }) {
  const location = useLocation();
  const { authedKey, signOut } = useApiKey();

  const sidebarTools = TOOLS.filter(t => t.id !== "dashboard");

  return (
    <div className="w-[200px] shrink-0 h-screen bg-white dark:bg-slate-900 border-r border-border flex flex-col overflow-y-auto scrollbar-thin">
      {/* Logo */}
      <div className="p-4 border-b border-border">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="text-sm font-bold text-foreground leading-none">AI Hub</div>
            <div className="text-xs text-muted-foreground">18 AI Tools</div>
          </div>
        </Link>
      </div>

      {/* Dashboard link */}
      <div className="px-2 pt-2">
        <Link
          to="/"
          className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
            location.pathname === "/"
              ? "bg-violet-600 text-white font-medium"
              : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          Dashboard
        </Link>
      </div>

      {/* Templates link */}
      <div className="px-2 pt-1">
        <Link
          to="/templates"
          className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
            location.pathname === "/templates"
              ? "bg-violet-600 text-white font-medium"
              : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          <BookOpen className="w-4 h-4" />
          Templates
        </Link>
      </div>

      {/* Projects link */}
      <div className="px-2 pt-1">
        <Link
          to="/projects"
          className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
            location.pathname === "/projects"
              ? "bg-violet-600 text-white font-medium"
              : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          <FolderOpen className="w-4 h-4" />
          My Projects
        </Link>
      </div>

      <div className="px-4 py-2">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">AI Tools (18)</div>
      </div>

      {/* Tool links */}
      <nav className="flex-1 px-2 py-1 space-y-0.5">
        {sidebarTools.map((tool) => {
          const isActive = location.pathname === tool.path;
          const Icon = ICON_MAP[tool.icon];
          return (
            <Link
              key={tool.id}
              to={tool.path}
              className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors ${
                isActive
                  ? "bg-violet-600 text-white font-medium"
                  : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              {Icon && <Icon className="w-4 h-4" />}
              {tool.label}
            </Link>
          );
        })}
      </nav>

      {/* Bottom controls */}
      <div className="p-3 border-t border-border space-y-1">
        {authedKey && (
          <div className="px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800 mb-1">
            <div className="text-[10px] text-muted-foreground">Signed in as</div>
            <div className="text-xs font-semibold text-foreground truncate">{authedKey.name}</div>
            <button onClick={signOut} className="flex items-center gap-1 text-[10px] text-red-500 hover:text-red-600 mt-0.5">
              <LogOut className="w-2.5 h-2.5" /> Sign out
            </button>
          </div>
        )}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="flex items-center gap-2 px-3 py-2 rounded-lg w-full text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          {darkMode ? "Light mode" : "Dark mode"}
        </button>
      </div>
    </div>
  );
}