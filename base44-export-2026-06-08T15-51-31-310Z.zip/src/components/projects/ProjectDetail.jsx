const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { ArrowLeft, Download, Trash2, FileText, Image, Code2, BarChart2, Mic, Music, Globe, Monitor, Mail, Zap, QrCode, FileDown, ClipboardList, MessageSquare } from "lucide-react";

import { useMutation, useQueryClient } from "@tanstack/react-query";

const TOOL_ICONS = {
  "Code Generator": Code2, "Data Analysis": BarChart2, "Voice Generator": Mic, "Music Creator": Music,
  "Website Builder": Globe, "Presentations": Monitor, "Letter Writer": Mail, "Productivity": Zap,
  "QR Generator": QrCode, "PDF Tools": FileDown, "Form Generator": ClipboardList, "AI Chat": MessageSquare,
  "Image Creator": Image, "Video Creator": FileText, "Resume Builder": FileText,
};

export default function ProjectDetail({ project, outputs, onBack, onRefresh }) {
  const qc = useQueryClient();

  const deleteOutput = useMutation({
    mutationFn: (id) => db.entities.SavedOutput.delete(id),
    onSuccess: onRefresh,
  });

  const exportProject = () => {
    let doc = `# ${project.name}\n`;
    if (project.description) doc += `_${project.description}_\n`;
    doc += `\nExported on ${new Date().toLocaleDateString()}\n\n---\n\n`;
    outputs.forEach(o => {
      doc += `## ${o.title} (${o.tool})\n\n${o.content}\n\n---\n\n`;
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([doc], { type: "text/markdown" }));
    a.download = `${project.name.replace(/\s+/g, "_")}.md`;
    a.click();
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={onBack} className="text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className={`w-3 h-8 rounded-full bg-gradient-to-b ${project.color || "from-violet-500 to-purple-600"}`} />
        <div className="flex-1">
          <h1 className="text-xl font-bold text-foreground">{project.name}</h1>
          {project.description && <p className="text-xs text-muted-foreground">{project.description}</p>}
        </div>
        {outputs.length > 0 && (
          <button
            onClick={exportProject}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border-2 border-border bg-white dark:bg-slate-800 text-sm font-medium hover:border-violet-300 transition-colors"
          >
            <Download className="w-4 h-4" />
            Export Project
          </button>
        )}
      </div>

      {/* Outputs */}
      {outputs.length === 0 ? (
        <div className="text-center py-20 border-2 border-dashed border-border rounded-2xl bg-white dark:bg-slate-800">
          <FileText className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <h3 className="font-semibold text-foreground mb-1">No outputs yet</h3>
          <p className="text-sm text-muted-foreground">Use any AI tool and save results to this project</p>
        </div>
      ) : (
        <div className="space-y-4">
          {outputs.map(output => {
            const Icon = TOOL_ICONS[output.tool] || FileText;
            return (
              <div key={output.id} className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-border p-5 group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center">
                      <Icon className="w-3.5 h-3.5 text-violet-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-sm">{output.title}</h3>
                      <span className="text-xs text-muted-foreground">{output.tool}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteOutput.mutate(output.id)}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-red-500 transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {output.image_url ? (
                  <img src={output.image_url} alt={output.title} className="rounded-xl w-full max-h-48 object-cover border border-border" />
                ) : (
                  <pre className="text-xs text-muted-foreground whitespace-pre-wrap line-clamp-6 bg-slate-50 dark:bg-slate-700/50 rounded-xl p-3 border border-border font-mono overflow-hidden">
                    {output.content}
                  </pre>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}