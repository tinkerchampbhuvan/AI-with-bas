const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { FolderPlus, Check, ChevronDown, Plus } from "lucide-react";

export default function SaveToProjectButton({ tool, title, content, imageUrl }) {
  const [open, setOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const qc = useQueryClient();

  const { data: projects = [] } = useQuery({
    queryKey: ["projects"],
    queryFn: () => db.entities.Project.list("-created_date"),
  });

  const save = async (projectId) => {
    if (saving) return;
    setSaving(true);
    setOpen(false);
    await db.entities.SavedOutput.create({
      project_id: projectId,
      tool,
      title: title || `${tool} output`,
      content: content || "",
      image_url: imageUrl || "",
    });
    qc.invalidateQueries({ queryKey: ["saved-outputs"] });
    setSaved(true);
    setSaving(false);
    setTimeout(() => setSaved(false), 3000);
  };

  if (saved) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-100 text-green-700 text-xs font-medium">
        <Check className="w-3.5 h-3.5" /> Saved!
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        disabled={saving}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-border bg-white dark:bg-slate-800 text-xs font-medium hover:border-violet-300 transition-colors disabled:opacity-50"
      >
        <FolderPlus className="w-3.5 h-3.5" />
        Save to Project
        <ChevronDown className="w-3 h-3 ml-0.5" />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-52 bg-white dark:bg-slate-800 rounded-xl border-2 border-border shadow-xl z-50 py-1 overflow-hidden">
          {projects.length === 0 ? (
            <div className="px-3 py-3 text-xs text-muted-foreground text-center">
              No projects yet — create one in the Projects page
            </div>
          ) : (
            projects.map(p => (
              <button
                key={p.id}
                onClick={() => save(p.id)}
                className="w-full text-left px-3 py-2 text-sm hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center gap-2 transition-colors"
              >
                <div className={`w-2.5 h-2.5 rounded-full bg-gradient-to-br ${p.color || "from-violet-500 to-purple-600"}`} />
                {p.name}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}