const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { BookmarkPlus, Check, X } from "lucide-react";

const CATEGORIES = ["Marketing", "Development", "Education", "Creative", "Business", "Personal", "Research", "Other"];

export default function SaveTemplateButton({ tool, prompt }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [category, setCategory] = useState("Other");
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!title.trim() || saving) return;
    setSaving(true);
    await db.entities.PromptTemplate.create({
      title: title.trim(),
      prompt: prompt.trim(),
      tool,
      category,
      description: desc.trim(),
      use_count: 0,
      is_favorite: false,
    });
    setSaving(false);
    setSaved(true);
    setOpen(false);
    setTitle(""); setDesc(""); setCategory("Other");
    setTimeout(() => setSaved(false), 3000);
  };

  if (saved) {
    return (
      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-100 text-green-700 text-xs font-medium">
        <Check className="w-3.5 h-3.5" /> Template Saved!
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        disabled={!prompt?.trim()}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-border bg-white dark:bg-slate-800 text-xs font-medium hover:border-violet-300 transition-colors disabled:opacity-40"
      >
        <BookmarkPlus className="w-3.5 h-3.5" />
        Save as Template
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-72 bg-white dark:bg-slate-800 rounded-xl border-2 border-border shadow-xl z-50 p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-foreground">Save Prompt Template</p>
            <button onClick={() => setOpen(false)}><X className="w-4 h-4 text-muted-foreground" /></button>
          </div>
          <input
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Template name..."
            className="w-full px-3 py-2 rounded-lg border border-border text-xs bg-slate-50 dark:bg-slate-700 mb-2 focus:outline-none focus:ring-2 focus:ring-violet-400"
          />
          <input
            value={desc}
            onChange={e => setDesc(e.target.value)}
            placeholder="Short description (optional)..."
            className="w-full px-3 py-2 rounded-lg border border-border text-xs bg-slate-50 dark:bg-slate-700 mb-2 focus:outline-none focus:ring-2 focus:ring-violet-400"
          />
          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
            className="w-full px-3 py-2 rounded-lg border border-border text-xs bg-slate-50 dark:bg-slate-700 mb-3 focus:outline-none"
          >
            {CATEGORIES.map(c => <option key={c}>{c}</option>)}
          </select>
          <div className="bg-slate-50 dark:bg-slate-700 rounded-lg p-2 mb-3 max-h-20 overflow-y-auto">
            <p className="text-xs text-muted-foreground line-clamp-3">{prompt}</p>
          </div>
          <button
            onClick={save}
            disabled={!title.trim() || saving}
            className="w-full py-2 rounded-lg bg-violet-600 text-white text-xs font-semibold disabled:opacity-40"
          >
            {saving ? "Saving..." : "Save Template"}
          </button>
        </div>
      )}
    </div>
  );
}