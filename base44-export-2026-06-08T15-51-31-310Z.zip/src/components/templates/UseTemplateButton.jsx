const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Star, ChevronDown, Clock } from "lucide-react";

export default function UseTemplateButton({ tool, onSelect }) {
  const [open, setOpen] = useState(false);
  const qc = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ["prompt-templates", tool],
    queryFn: () => db.entities.PromptTemplate.filter(
      tool === "Any" ? {} : { tool },
      "-use_count",
      20
    ),
    enabled: open,
  });

  const use = async (template) => {
    onSelect(template.prompt);
    setOpen(false);
    await db.entities.PromptTemplate.update(template.id, { use_count: (template.use_count || 0) + 1 });
    qc.invalidateQueries({ queryKey: ["prompt-templates"] });
  };

  const favorites = templates.filter(t => t.is_favorite);
  const rest = templates.filter(t => !t.is_favorite);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border-2 border-border bg-white dark:bg-slate-800 text-xs font-medium hover:border-violet-300 transition-colors"
      >
        <BookOpen className="w-3.5 h-3.5 text-violet-500" />
        Templates
        <ChevronDown className="w-3 h-3" />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-full mt-1 w-72 bg-white dark:bg-slate-800 rounded-xl border-2 border-border shadow-xl z-50 py-2 max-h-80 overflow-y-auto">
            {templates.length === 0 ? (
              <div className="px-4 py-6 text-center">
                <BookOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                <p className="text-xs text-muted-foreground">No saved templates yet.</p>
                <p className="text-xs text-muted-foreground mt-1">Save prompts with the "Save as Template" button.</p>
              </div>
            ) : (
              <>
                {favorites.length > 0 && (
                  <div className="px-3 py-1">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">⭐ Favorites</p>
                    {favorites.map(t => <TemplateRow key={t.id} template={t} onUse={use} />)}
                  </div>
                )}
                {rest.length > 0 && (
                  <div className="px-3 py-1">
                    {favorites.length > 0 && <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1 mt-2">All Templates</p>}
                    {rest.map(t => <TemplateRow key={t.id} template={t} onUse={use} />)}
                  </div>
                )}
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function TemplateRow({ template, onUse }) {
  return (
    <button
      onClick={() => onUse(template)}
      className="w-full text-left px-2 py-2.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors mb-0.5"
    >
      <div className="flex items-start gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-foreground truncate">{template.title}</p>
          {template.description && <p className="text-xs text-muted-foreground truncate">{template.description}</p>}
          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1 opacity-70">{template.prompt.slice(0, 80)}…</p>
        </div>
        {template.use_count > 0 && (
          <div className="flex items-center gap-0.5 shrink-0 text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span className="text-xs">{template.use_count}</span>
          </div>
        )}
      </div>
    </button>
  );
}