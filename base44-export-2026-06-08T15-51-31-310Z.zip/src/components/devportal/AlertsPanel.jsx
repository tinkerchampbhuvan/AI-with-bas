const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };


import { useQueryClient } from "@tanstack/react-query";
import { X, AlertTriangle, RotateCcw, Info, CheckCheck } from "lucide-react";

const ICONS = {
  leak: AlertTriangle,
  rotation: RotateCcw,
  info: Info,
};

const COLORS = {
  leak: "text-red-500 bg-red-100 dark:bg-red-900/30",
  rotation: "text-yellow-500 bg-yellow-100 dark:bg-yellow-900/30",
  info: "text-blue-500 bg-blue-100 dark:bg-blue-900/30",
};

export default function AlertsPanel({ alerts, onClose, onRefresh }) {
  const qc = useQueryClient();

  const markAllRead = async () => {
    const unread = alerts.filter(a => !a.read);
    await Promise.all(unread.map(a => db.entities.KeyAlert.update(a.id, { read: true })));
    qc.invalidateQueries({ queryKey: ["key-alerts"] });
    onRefresh();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-end">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 h-full overflow-y-auto shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-5 border-b border-border sticky top-0 bg-white dark:bg-slate-900 z-10">
          <h2 className="font-bold text-foreground">Security Alerts</h2>
          <div className="flex gap-2">
            {alerts.some(a => !a.read) && (
              <button
                onClick={markAllRead}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs border border-border hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
              >
                <CheckCheck className="w-3.5 h-3.5" /> Mark all read
              </button>
            )}
            <button onClick={onClose}><X className="w-5 h-5 text-muted-foreground" /></button>
          </div>
        </div>

        <div className="flex-1 p-4 space-y-3">
          {alerts.length === 0 && (
            <div className="text-center py-16 text-muted-foreground text-sm">No alerts yet</div>
          )}
          {alerts.map(alert => {
            const Icon = ICONS[alert.type] || Info;
            const color = COLORS[alert.type] || COLORS.info;
            return (
              <div
                key={alert.id}
                className={`rounded-xl p-4 flex gap-3 border ${alert.read ? "border-border opacity-60" : "border-current"} ${
                  alert.type === "leak" ? "border-red-200 dark:border-red-800" :
                  alert.type === "rotation" ? "border-yellow-200 dark:border-yellow-800" :
                  "border-blue-200 dark:border-blue-800"
                } ${
                  alert.type === "leak" ? "bg-red-50 dark:bg-red-900/10" :
                  alert.type === "rotation" ? "bg-yellow-50 dark:bg-yellow-900/10" :
                  "bg-blue-50 dark:bg-blue-900/10"
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground leading-relaxed">{alert.message}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {new Date(alert.created_date).toLocaleString()}
                  </p>
                </div>
                {!alert.read && (
                  <div className="w-2 h-2 rounded-full bg-red-500 shrink-0 mt-1" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}