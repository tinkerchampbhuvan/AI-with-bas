import { useState } from "react";
import { X, BarChart2, Code2, Shield } from "lucide-react";
import KeyAnalytics from "./KeyAnalytics";
import QuickStartSDK from "./QuickStartSDK";

const TABS = ["Analytics", "Quick Start", "Security"];

export default function KeyDetailPanel({ apiKey, onClose, onRefresh }) {
  const [tab, setTab] = useState("Analytics");

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-end">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border sticky top-0 bg-white dark:bg-slate-900 z-10">
          <div>
            <h2 className="font-bold text-foreground">{apiKey.name}</h2>
            <p className="text-xs font-mono text-muted-foreground mt-0.5">{apiKey.key_id}</p>
          </div>
          <button onClick={onClose}><X className="w-5 h-5 text-muted-foreground" /></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border px-5">
          {TABS.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                tab === t ? "border-violet-600 text-violet-600" : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex-1 p-5">
          {tab === "Analytics" && <KeyAnalytics apiKey={apiKey} />}
          {tab === "Quick Start" && <QuickStartSDK apiKey={apiKey} />}
          {tab === "Security" && (
            <div className="space-y-4">
              <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4">
                <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-violet-500" /> Security Details
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Public Key ID</span>
                    <span className="font-mono text-xs text-foreground">{apiKey.key_id}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Masked Secret</span>
                    <span className="font-mono text-xs text-foreground">{apiKey.secret_masked}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Secret Hash (SHA-256)</span>
                    <span className="font-mono text-[10px] text-muted-foreground truncate max-w-[180px]">{apiKey.secret_hash?.slice(0, 20)}…</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Status</span>
                    <span className="capitalize font-semibold text-foreground">{apiKey.status}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Scopes</span>
                    <span className="text-foreground">{apiKey.scopes?.join(", ") || "—"}</span>
                  </div>
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">IP Whitelist</span>
                    <span className="text-foreground text-xs">{apiKey.ip_whitelist || "All IPs allowed"}</span>
                  </div>
                </div>
              </div>

              {apiKey.status === "rotating" && apiKey.rotation_expires_at && (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl p-4">
                  <p className="text-sm font-semibold text-yellow-700 dark:text-yellow-400 mb-1">🔄 Key Rotation Active</p>
                  <p className="text-xs text-yellow-600 dark:text-yellow-500">
                    Old key remains valid until {new Date(apiKey.rotation_expires_at).toLocaleString()} for zero-downtime transition.
                  </p>
                </div>
              )}

              {apiKey.status === "quarantined" && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4">
                  <p className="text-sm font-semibold text-red-700 dark:text-red-400 mb-1">🚨 Key Quarantined</p>
                  <p className="text-xs text-red-600 dark:text-red-500">
                    This key was flagged by the Secret Scanner as potentially exposed and has been automatically suspended.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}