const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { X, Loader2 } from "lucide-react";

const SCOPES = [
  { id: "read", label: "Read-Only", desc: "GET requests only" },
  { id: "write", label: "Write-Only", desc: "POST/PUT/DELETE requests" },
  { id: "billing", label: "Billing-Admin", desc: "Access billing & invoices" },
  { id: "full", label: "Full-Access", desc: "All permissions" },
];

function generateKeyId() {
  return "key_id_" + Math.random().toString(36).slice(2, 10);
}

function generateSecret() {
  return "sk_live_" + Array.from(crypto.getRandomValues(new Uint8Array(18)))
    .map(b => b.toString(16).padStart(2, "0")).join("");
}

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function maskSecret(secret) {
  return secret.slice(0, 8) + "•••••••••" + secret.slice(-4);
}

export default function CreateKeyModal({ onClose, onCreated }) {
  const [name, setName] = useState("");
  const [scopes, setScopes] = useState([]);
  const [ipWhitelist, setIpWhitelist] = useState("");
  const [loading, setLoading] = useState(false);

  const toggleScope = (id) => {
    setScopes(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);
  };

  const create = async () => {
    if (!name.trim() || scopes.length === 0 || loading) return;
    setLoading(true);
    const rawSecret = generateSecret();
    const hash = await sha256(rawSecret);
    const keyId = generateKeyId();
    const record = await db.entities.ApiKey.create({
      name: name.trim(),
      key_id: keyId,
      secret_hash: hash,
      secret_masked: maskSecret(rawSecret),
      scopes,
      ip_whitelist: ipWhitelist.trim(),
      status: "active",
      total_requests: Math.floor(Math.random() * 8000) + 200,
      success_requests: Math.floor(Math.random() * 7000) + 150,
      failed_requests: Math.floor(Math.random() * 500) + 10,
      avg_latency_ms: Math.floor(Math.random() * 180) + 40,
      data_transfer_mb: parseFloat((Math.random() * 500 + 10).toFixed(1)),
    });
    setLoading(false);
    onClose();
    onCreated(rawSecret, record);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-border shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="font-bold text-foreground">Create New API Key</h2>
          <button onClick={onClose}><X className="w-5 h-5 text-muted-foreground" /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-foreground mb-1">Key Name</label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Production Backend"
              className="w-full px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-foreground mb-2">Permission Scopes</label>
            <div className="grid grid-cols-2 gap-2">
              {SCOPES.map(s => (
                <button
                  key={s.id}
                  onClick={() => toggleScope(s.id)}
                  className={`text-left p-3 rounded-xl border-2 transition-colors ${
                    scopes.includes(s.id)
                      ? "border-violet-500 bg-violet-50 dark:bg-violet-900/30"
                      : "border-border bg-white dark:bg-slate-800"
                  }`}
                >
                  <div className="text-xs font-semibold text-foreground">{s.label}</div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-foreground mb-1">IP Whitelist <span className="text-muted-foreground font-normal">(optional)</span></label>
            <input
              value={ipWhitelist}
              onChange={e => setIpWhitelist(e.target.value)}
              placeholder="192.168.1.1, 10.0.0.1"
              className="w-full px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
            />
            <p className="text-[10px] text-muted-foreground mt-1">Comma-separated. Leave blank to allow all IPs.</p>
          </div>
        </div>

        <div className="flex gap-3 p-5 border-t border-border">
          <button onClick={onClose} className="flex-1 px-4 py-2 rounded-xl border border-border text-sm font-medium">Cancel</button>
          <button
            onClick={create}
            disabled={!name.trim() || scopes.length === 0 || loading}
            className="flex-1 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-semibold disabled:opacity-40 flex items-center justify-center gap-2"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Generate Key
          </button>
        </div>
      </div>
    </div>
  );
}