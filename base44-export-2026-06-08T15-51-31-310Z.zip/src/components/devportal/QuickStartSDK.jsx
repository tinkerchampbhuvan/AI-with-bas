import { useState } from "react";
import { Copy, Check } from "lucide-react";

const TABS = ["JavaScript", "Python", "cURL"];

function jsSnippet(keyId) {
  return `// Install: npm install node-fetch
const fetch = require('node-fetch');

const response = await fetch('https://api.yourservice.com/v1/data', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer ${keyId}',
    'Content-Type': 'application/json',
  },
});

const data = await response.json();
console.log(data);`;
}

function pythonSnippet(keyId) {
  return `# Install: pip install requests
import requests

headers = {
    "Authorization": f"Bearer ${keyId}",
    "Content-Type": "application/json",
}

response = requests.get(
    "https://api.yourservice.com/v1/data",
    headers=headers
)

print(response.json())`;
}

function curlSnippet(keyId) {
  return `curl -X GET "https://api.yourservice.com/v1/data" \\
  -H "Authorization: Bearer ${keyId}" \\
  -H "Content-Type: application/json"`;
}

export default function QuickStartSDK({ apiKey }) {
  const [tab, setTab] = useState("JavaScript");
  const [copied, setCopied] = useState(false);

  const snippets = {
    JavaScript: jsSnippet(apiKey.key_id),
    Python: pythonSnippet(apiKey.key_id),
    cURL: curlSnippet(apiKey.key_id),
  };

  const copy = () => {
    navigator.clipboard.writeText(snippets[tab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-1">Quick Start SDK</h3>
        <p className="text-xs text-muted-foreground">Your public key ID is automatically embedded in the snippets below.</p>
      </div>

      {/* Language tabs */}
      <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 rounded-xl p-1 w-fit">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              tab === t
                ? "bg-white dark:bg-slate-700 text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Code block */}
      <div className="relative bg-slate-950 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800">
          <span className="text-xs text-slate-400 font-mono">{tab.toLowerCase() === "javascript" ? "index.js" : tab.toLowerCase() === "python" ? "main.py" : "request.sh"}</span>
          <button
            onClick={copy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 transition-colors"
          >
            {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
            {copied ? "Copied!" : "Copy"}
          </button>
        </div>
        <pre className="p-4 text-xs text-green-300 font-mono overflow-x-auto whitespace-pre leading-relaxed">
          {snippets[tab]}
        </pre>
      </div>

      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-3 text-xs text-blue-700 dark:text-blue-400">
        <strong>Base URL:</strong> https://api.yourservice.com/v1<br />
        <strong>Auth:</strong> Bearer token in Authorization header<br />
        <strong>Rate limit:</strong> 1,000 requests/min (adjustable)
      </div>
    </div>
  );
}