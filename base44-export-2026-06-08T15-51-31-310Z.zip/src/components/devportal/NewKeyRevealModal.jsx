import { useState } from "react";
import { Copy, Check, ShieldCheck, X } from "lucide-react";

export default function NewKeyRevealModal({ secret, record, onClose }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    navigator.clipboard.writeText(secret);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-border shadow-2xl w-full max-w-lg">
        <div className="p-6 text-center">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
            <ShieldCheck className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-xl font-bold text-foreground mb-1">Your Secret Key</h2>
          <p className="text-sm text-red-500 font-medium mb-4">⚠️ Copy this now — it will never be shown again!</p>

          <div className="bg-slate-950 rounded-xl p-4 font-mono text-sm text-green-400 break-all text-left mb-3 relative">
            {secret}
            <button
              onClick={copy}
              className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            </button>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 text-xs text-left space-y-1.5 mb-5">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Public Key ID</span>
              <span className="font-mono font-semibold text-foreground">{record.key_id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Masked Secret</span>
              <span className="font-mono text-foreground">{record.secret_masked}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Scopes</span>
              <span className="font-semibold text-foreground">{record.scopes?.join(", ")}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-semibold"
          >
            I've saved my key — Continue
          </button>
        </div>
      </div>
    </div>
  );
}