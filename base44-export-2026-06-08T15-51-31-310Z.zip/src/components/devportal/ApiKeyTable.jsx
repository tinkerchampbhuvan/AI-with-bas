const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQueryClient } from "@tanstack/react-query";
import { RotateCcw, Trash2, AlertTriangle, ChevronRight, Shield } from "lucide-react";

const STATUS_STYLES = {
  active: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  rotating: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
  quarantined: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  revoked: "bg-slate-100 text-slate-500 dark:bg-slate-800",
};

function RotationCountdown({ expiresAt }) {
  const ms = new Date(expiresAt) - Date.now();
  if (ms <= 0) return <span className="text-xs text-muted-foreground">Expiring…</span>;
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  return <span className="text-xs text-yellow-600 font-mono font-semibold">{h}h {m}m left</span>;
}

export default function ApiKeyTable({ keys, onSelect, onRefresh }) {
  const qc = useQueryClient();
  const [rotating, setRotating] = useState(null);

  const rotate = async (e, key) => {
    e.stopPropagation();
    if (rotating) return;
    setRotating(key.id);
    const expiresAt = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
    await db.entities.ApiKey.update(key.id, {
      status: "rotating",
      rotation_expires_at: expiresAt,
    });
    await db.entities.KeyAlert.create({
      key_id: key.id,
      key_name: key.name,
      message: `Key "${key.name}" is rotating. Old key valid until ${new Date(expiresAt).toLocaleString()}.`,
      type: "rotation",
    });
    qc.invalidateQueries({ queryKey: ["api-keys"] });
    qc.invalidateQueries({ queryKey: ["key-alerts"] });
    setRotating(null);
    onRefresh();
  };

  const simulateLeak = async (e, key) => {
    e.stopPropagation();
    await db.entities.ApiKey.update(key.id, { status: "quarantined" });
    await db.entities.KeyAlert.create({
      key_id: key.id,
      key_name: key.name,
      message: `🚨 SECURITY ALERT: Key "${key.name}" (${key.key_id}) was detected in a public repository. It has been automatically quarantined.`,
      type: "leak",
    });
    qc.invalidateQueries({ queryKey: ["api-keys"] });
    qc.invalidateQueries({ queryKey: ["key-alerts"] });
    onRefresh();
  };

  const revoke = async (e, key) => {
    e.stopPropagation();
    if (!confirm(`Permanently revoke "${key.name}"?`)) return;
    await db.entities.ApiKey.update(key.id, { status: "revoked" });
    qc.invalidateQueries({ queryKey: ["api-keys"] });
    onRefresh();
  };

  if (keys.length === 0) return null;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-slate-50 dark:bg-slate-900/50">
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Name</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Public Key ID</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Secret</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Scopes</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Status</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Requests</th>
              <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {keys.map(key => (
              <tr
                key={key.id}
                onClick={() => onSelect(key)}
                className="border-b border-border last:border-0 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition-colors group"
              >
                <td className="px-4 py-3">
                  <div className="font-semibold text-foreground">{key.name}</div>
                  {key.ip_whitelist && (
                    <div className="flex items-center gap-1 mt-0.5">
                      <Shield className="w-2.5 h-2.5 text-blue-500" />
                      <span className="text-[10px] text-blue-500">IP restricted</span>
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{key.key_id}</td>
                <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{key.secret_masked}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {(key.scopes || []).map(s => (
                      <span key={s} className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300">{s}</span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-1">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold w-fit ${STATUS_STYLES[key.status] || STATUS_STYLES.revoked}`}>
                      {key.status}
                    </span>
                    {key.status === "rotating" && key.rotation_expires_at && (
                      <RotationCountdown expiresAt={key.rotation_expires_at} />
                    )}
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{(key.total_requests || 0).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                    {key.status === "active" && (
                      <>
                        <button
                          onClick={e => rotate(e, key)}
                          disabled={rotating === key.id}
                          title="Rotate Key"
                          className="p-1.5 rounded-lg hover:bg-yellow-100 dark:hover:bg-yellow-900/30 text-yellow-600 transition-colors"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={e => simulateLeak(e, key)}
                          title="Simulate Leak (Secret Scanner)"
                          className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500 transition-colors"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                    <button
                      onClick={e => revoke(e, key)}
                      title="Revoke Key"
                      className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}