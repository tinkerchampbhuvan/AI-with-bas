import { useMemo } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";

function generateDailyData(total, success, failed) {
  const days = 30;
  const data = [];
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const label = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    const base = Math.floor((total / days) * (0.5 + Math.random()));
    const s = Math.floor(base * (success / total) * (0.8 + Math.random() * 0.4));
    const f = Math.max(0, Math.floor(base * (failed / total) * (0.5 + Math.random())));
    data.push({ date: label, requests: base, success: s, errors: f, latency: Math.floor(40 + Math.random() * 150) });
  }
  return data;
}

export default function KeyAnalytics({ apiKey }) {
  const data = useMemo(() => generateDailyData(
    apiKey.total_requests || 1000,
    apiKey.success_requests || 900,
    apiKey.failed_requests || 100
  ), [apiKey.id]);

  const successRate = apiKey.total_requests
    ? ((apiKey.success_requests / apiKey.total_requests) * 100).toFixed(1)
    : "0";

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Total Requests", value: (apiKey.total_requests || 0).toLocaleString() },
          { label: "Success Rate", value: `${successRate}%` },
          { label: "Avg Latency", value: `${apiKey.avg_latency_ms || 0}ms` },
          { label: "Data Transfer", value: `${apiKey.data_transfer_mb || 0} MB` },
        ].map(kpi => (
          <div key={kpi.label} className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3">
            <div className="text-lg font-bold text-foreground">{kpi.value}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Requests over time */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">API Requests — Last 30 Days</h3>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gSuccess" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gErrors" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="date" tick={{ fontSize: 9 }} tickLine={false} interval={6} />
              <YAxis tick={{ fontSize: 9 }} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
              <Area type="monotone" dataKey="success" stroke="#8b5cf6" fill="url(#gSuccess)" strokeWidth={2} name="200 OK" />
              <Area type="monotone" dataKey="errors" stroke="#ef4444" fill="url(#gErrors)" strokeWidth={2} name="401/5xx" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Latency chart */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">Avg Response Latency (ms)</h3>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.filter((_, i) => i % 3 === 0)} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <XAxis dataKey="date" tick={{ fontSize: 9 }} tickLine={false} />
              <YAxis tick={{ fontSize: 9 }} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8 }} />
              <Bar dataKey="latency" fill="#a78bfa" radius={[3, 3, 0, 0]} name="Latency (ms)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}