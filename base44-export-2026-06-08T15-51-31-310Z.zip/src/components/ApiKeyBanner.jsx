import { useState } from "react";
import { useApiKey } from "@/lib/ApiKeyContext";
import { KeyRound, X, Loader2, AlertTriangle } from "lucide-react";

export default function ApiKeyBanner() {
  const { authedKey, authenticate } = useApiKey();
  const [open, setOpen] = useState(false);
  const [keyInput, setKeyInput] = useState("");
  const [validating, setValidating] = useState(false);
  const [error, setError] = useState("");

  if (authedKey) return null;

  const handleAuth = async () => {
    if (!keyInput.trim() || validating) return;
    setValidating(true);
    setError("");
    try {
      await authenticate(keyInput.trim());
      setOpen(false);
      setKeyInput("");
    } catch (e) {
      setError(e.message);
    }
    setValidating(false);
  };

  return (
    <>
      {/* Sticky banner */}
      <div className="bg-amber-50 dark:bg-amber-900/30 border-b border-amber-200 dark:border-amber-700 px-4 py-2.5 flex items-center gap-3">
        <KeyRound className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
        <span className="text-xs text-amber-800 dark:text-amber-300 flex-1">
          No API key — you can browse the app but tools are disabled.
        </span>
        <button
          onClick={() => setOpen(true)}
          className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold transition-colors"
        >
          Enter key
        </button>
      </div>

      {/* Modal */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-border shadow-2xl p-6 w-full max-w-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-foreground">Enter API Key</h2>
              <button onClick={() => { setOpen(false); setError(""); }} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>

            <input
              type="password"
              value={keyInput}
              onChange={e => setKeyInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleAuth()}
              placeholder="sk_live_••••••••••••••••••••"
              className="w-full px-3 py-2.5 rounded-xl border border-border bg-slate-50 dark:bg-slate-900 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-violet-400"
              autoFocus
            />

            {error && (
              <div className="flex items-start gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-xl p-3 text-xs text-red-600 dark:text-red-400">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            <button
              onClick={handleAuth}
              disabled={!keyInput.trim() || validating}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-700 text-white text-sm font-semibold disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {validating ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
              {validating ? "Validating…" : "Activate Key"}
            </button>

            <p className="text-center text-[11px] text-muted-foreground">
              No key yet? <a href="/dev-portal" className="text-violet-600 hover:underline">Generate one in the Dev Portal</a>
            </p>
          </div>
        </div>
      )}
    </>
  );
}