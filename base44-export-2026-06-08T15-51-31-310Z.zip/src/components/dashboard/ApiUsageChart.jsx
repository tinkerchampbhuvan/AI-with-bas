const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from "react";

import { useApiKey } from "@/lib/ApiKeyContext";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Activity, CheckCircle2, XCircle, Link } from "lucide-react";

export default function ApiUsageChart() {
  const { authedKey } = useApiKey();
  const [keys, setKeys] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.entities.ApiKey.list("-total_requests", 20).
    then((data) => {setKeys(data || []);setLoading(false);}).
    catch(() => setLoading(false));
  }, []);

  if (loading) return null;

  const totalRequests = keys.reduce((s, k) => s + (k.total_requests || 0), 0);
  const totalSuccess = keys.reduce((s, k) => s + (k.success_requests || 0), 0);
  const totalFailed = keys.reduce((s, k) => s + (k.failed_requests || 0), 0);
  const activeKeys = keys.filter((k) => k.status === "active").length;

  // Chart data: per-key breakdown
  const chartData = keys.
  filter((k) => (k.total_requests || 0) > 0).
  map((k) => ({ name: k.name, requests: k.total_requests || 0, success: k.success_requests || 0 })).
  slice(0, 8);

  const COLORS = ["#7c3aed", "#8b5cf6", "#a78bfa", "#c4b5fd", "#6d28d9", "#5b21b6", "#4c1d95", "#ede9fe"];

  return null;

}