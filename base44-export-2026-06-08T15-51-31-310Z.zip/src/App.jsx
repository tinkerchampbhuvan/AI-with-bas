import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { ApiKeyProvider } from '@/lib/ApiKeyContext';
import ApiKeyGate from '@/components/ApiKeyGate';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from '@/components/AppLayout';
import Dashboard from '@/pages/Dashboard';
import AiChat from '@/pages/tools/AiChat';
import WebsiteBuilder from '@/pages/tools/WebsiteBuilder';
import Presentations from '@/pages/tools/Presentations';
import ImageCreator from '@/pages/tools/ImageCreator';
import VideoCreator from '@/pages/tools/VideoCreator';
import LetterWriter from '@/pages/tools/LetterWriter';
import VoiceGenerator from '@/pages/tools/VoiceGenerator';
import CodeGenerator from '@/pages/tools/CodeGenerator';
import DataAnalysis from '@/pages/tools/DataAnalysis';
import Productivity from '@/pages/tools/Productivity';
import MusicCreator from '@/pages/tools/MusicCreator';
import QrGenerator from '@/pages/tools/QrGenerator';
import ResumeBuilder from '@/pages/tools/ResumeBuilder';
import PdfTools from '@/pages/tools/PdfTools';
import FormGenerator from '@/pages/tools/FormGenerator';
import Projects from '@/pages/Projects';
import DevPortal from '@/pages/tools/DevPortal';
import ApiPlayground from '@/pages/tools/ApiPlayground';
import Templates from '@/pages/Templates';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-violet-600 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <ApiKeyProvider>
      <ApiKeyGate>
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/ai-chat" element={<AiChat />} />
        <Route path="/website-builder" element={<WebsiteBuilder />} />
        <Route path="/presentations" element={<Presentations />} />
        <Route path="/image-creator" element={<ImageCreator />} />
        <Route path="/video-creator" element={<VideoCreator />} />
        <Route path="/letter-writer" element={<LetterWriter />} />
        <Route path="/voice-generator" element={<VoiceGenerator />} />
        <Route path="/code-generator" element={<CodeGenerator />} />
        <Route path="/data-analysis" element={<DataAnalysis />} />
        <Route path="/productivity" element={<Productivity />} />
        <Route path="/music-creator" element={<MusicCreator />} />
        <Route path="/qr-generator" element={<QrGenerator />} />
        <Route path="/resume-builder" element={<ResumeBuilder />} />
        <Route path="/pdf-tools" element={<PdfTools />} />
        <Route path="/form-generator" element={<FormGenerator />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/dev-portal" element={<DevPortal />} />
        <Route path="/api-playground" element={<ApiPlayground />} />
        <Route path="/templates" element={<Templates />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
      </ApiKeyGate>
    </ApiKeyProvider>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App