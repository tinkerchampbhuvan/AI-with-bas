const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { TOOLS } from "@/lib/tools";

import ApiUsageChart from "@/components/dashboard/ApiUsageChart";
import { Sparkles, Loader2, Globe, Monitor, Image, Video, Mail, Mic, Code2, BarChart2, Zap, Music, QrCode, FileText, FileDown, ClipboardList, MessageSquare, KeyRound, FlaskConical } from "lucide-react";

const ICON_MAP = { Globe, Monitor, Image, Video, Mail, Mic, Code2, BarChart2, Zap, Music, QrCode, FileText, FileDown, ClipboardList, MessageSquare, KeyRound, FlaskConical };

export default function Dashboard() {
  const [magicPrompt, setMagicPrompt] = useState("");
  const [magicLoading, setMagicLoading] = useState(false);
  const navigate = useNavigate();

  const displayTools = TOOLS.filter(t => t.id !== "dashboard");

  const handleMagicCreate = async () => {
    if (!magicPrompt.trim() || magicLoading) return;
    setMagicLoading(true);
    const result = await db.integrations.Core.InvokeLLM({
      prompt: `Given this user request: "${magicPrompt}", which tool page should they go to? Choose exactly one from this list and return ONLY the path string (e.g. /ai-chat):
/ai-chat, /website-builder, /presentations, /image-creator, /video-creator, /letter-writer, /voice-generator, /code-generator, /data-analysis, /productivity, /music-creator, /qr-generator, /resume-builder, /pdf-tools, /form-generator`,
    });
    setMagicLoading(false);
    const path = result.trim().match(/\/[a-z-]+/)?.[0];
    if (path) navigate(path);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Magic Create */}
      <div className="text-center mb-8">
        <button className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-gradient-to-r from-violet-500 to-purple-600 text-white text-sm font-semibold shadow-lg shadow-violet-200 dark:shadow-violet-900/30 mb-4">
          <Sparkles className="w-4 h-4" />
          Magic Create
        </button>
        <div className="flex gap-2 max-w-xl mx-auto border-2 border-violet-200 dark:border-violet-700 rounded-2xl p-1.5 bg-white dark:bg-slate-800 shadow-sm">
          <input
            value={magicPrompt}
            onChange={e => setMagicPrompt(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleMagicCreate()}
            placeholder="Speak to create anything — it will auto-generate on the right page"
            className="flex-1 px-4 py-2.5 rounded-xl bg-transparent text-sm focus:outline-none"
          />
          <button
            onClick={handleMagicCreate}
            disabled={magicLoading}
            className="px-4 py-2.5 rounded-xl bg-violet-600 text-white text-sm font-medium disabled:opacity-50 flex items-center gap-2"
          >
            {magicLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <ApiUsageChart />

      {/* Tools Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {displayTools.map((tool) => {
          const Icon = ICON_MAP[tool.icon];
          return (
            <Link
              key={tool.id}
              to={tool.path}
              className="bg-white dark:bg-slate-800 rounded-2xl p-5 border-2 border-border hover:border-violet-300 dark:hover:border-violet-600 hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 group"
            >
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center mb-3 shadow-sm`}>
                {Icon && <Icon className="w-5 h-5 text-white" />}
              </div>
              <h3 className="font-semibold text-foreground text-sm mb-1">{tool.label}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{tool.description}</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}