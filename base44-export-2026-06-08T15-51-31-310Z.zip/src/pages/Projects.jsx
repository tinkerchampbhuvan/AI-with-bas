const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Plus, FolderOpen, Trash2, Download, ChevronRight, FileText, Image, Code2, BarChart2, Mic, Music, Globe, Monitor, Mail, Zap, QrCode, FileDown, ClipboardList, MessageSquare, GripVertical, Inbox } from "lucide-react";
import ProjectDetail from "@/components/projects/ProjectDetail";
import NewProjectModal from "@/components/projects/NewProjectModal";

const TOOL_ICONS = {
  "Code Generator": Code2, "Data Analysis": BarChart2, "Voice Generator": Mic, "Music Creator": Music,
  "Website Builder": Globe, "Presentations": Monitor, "Letter Writer": Mail, "Productivity": Zap,
  "QR Generator": QrCode, "PDF Tools": FileDown, "Form Generator": ClipboardList, "AI Chat": MessageSquare,
  "Image Creator": Image, "Video Creator": FileText, "Resume Builder": FileText,
};

const PROJECT_COLORS = [
  "from-violet-500 to-purple-600", "from-blue-500 to-cyan-500", "from-pink-500 to-rose-500",
  "from-teal-500 to-green-500", "from-orange-500 to-red-500", "from-fuchsia-500 to-pink-500",
  "from-indigo-500 to-blue-500", "from-cyan-500 to-blue-500",
];

export default function Projects() {
  const [selectedProject, setSelectedProject] = useState(null);
  const [showNewProject, setShowNewProject] = useState(false);
  const [draggingOver, setDraggingOver] = useState(null);
  const qc = useQueryClient();

  const { data: projects = [] } = useQuery({
    queryKey: ["projects"],
    queryFn: () => db.entities.Project.list("-created_date"),
  });

  const { data: outputs = [] } = useQuery({
    queryKey: ["saved-outputs"],
    queryFn: () => db.entities.SavedOutput.list("-created_date"),
  });

  const moveOutput = useMutation({
    mutationFn: ({ id, project_id }) => db.entities.SavedOutput.update(id, { project_id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["saved-outputs"] }),
  });

  const deleteProject = useMutation({
    mutationFn: async (id) => {
      await db.entities.Project.delete(id);
      const projectOutputs = outputs.filter(o => o.project_id === id);
      await Promise.all(projectOutputs.map(o => db.entities.SavedOutput.delete(o.id)));
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      qc.invalidateQueries({ queryKey: ["saved-outputs"] });
    },
  });

  const exportAll = () => {
    let doc = `# AI Generated Reports & Data\nExported on ${new Date().toLocaleDateString()}\n\n`;
    projects.forEach(project => {
      const projectOutputs = outputs.filter(o => o.project_id === project.id);
      if (projectOutputs.length === 0) return;
      doc += `## 📁 ${project.name}\n`;
      if (project.description) doc += `_${project.description}_\n\n`;
      projectOutputs.forEach(o => {
        doc += `### ${o.title} (${o.tool})\n${o.content}\n\n---\n\n`;
      });
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([doc], { type: "text/markdown" }));
    a.download = `AI_Reports_${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
  };

  const onDragEnd = (result) => {
    setDraggingOver(null);
    const { draggableId, destination } = result;
    if (!destination) return;
    const destProjectId = destination.droppableId === "unorganized" ? null : destination.droppableId;
    const output = outputs.find(o => o.id === draggableId);
    if (!output) return;
    if (output.project_id === destProjectId) return;
    moveOutput.mutate({ id: draggableId, project_id: destProjectId });
  };

  const onDragUpdate = (update) => {
    setDraggingOver(update.destination?.droppableId || null);
  };

  const unorganized = outputs.filter(o => !o.project_id);
  const getProjectOutputs = (id) => outputs.filter(o => o.project_id === id);

  if (selectedProject) {
    return (
      <ProjectDetail
        project={selectedProject}
        outputs={outputs.filter(o => o.project_id === selectedProject.id)}
        onBack={() => setSelectedProject(null)}
        onRefresh={() => qc.invalidateQueries({ queryKey: ["saved-outputs"] })}
      />
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">My Projects</h1>
          <p className="text-sm text-muted-foreground mt-1">Drag outputs into project folders to organize your work</p>
        </div>
        <div className="flex gap-2">
          {outputs.length > 0 && (
            <button onClick={exportAll} className="flex items-center gap-2 px-4 py-2 rounded-xl border-2 border-border bg-white dark:bg-slate-800 text-sm font-medium hover:border-violet-300 transition-colors">
              <Download className="w-4 h-4" /> Export All
            </button>
          )}
          <button onClick={() => setShowNewProject(true)} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 text-white text-sm font-semibold shadow-sm">
            <Plus className="w-4 h-4" /> New Project
          </button>
        </div>
      </div>

      <DragDropContext onDragEnd={onDragEnd} onDragUpdate={onDragUpdate}>
        <div className="flex gap-6 items-start">
          {/* Unorganized inbox */}
          <div className="w-72 shrink-0">
            <div className="flex items-center gap-2 mb-3">
              <Inbox className="w-4 h-4 text-muted-foreground" />
              <span className="font-semibold text-sm text-foreground">Unsorted</span>
              <span className="text-xs bg-slate-100 dark:bg-slate-700 px-1.5 py-0.5 rounded-full text-muted-foreground">{unorganized.length}</span>
            </div>
            <Droppable droppableId="unorganized">
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`min-h-32 rounded-2xl border-2 border-dashed transition-colors p-2 space-y-2 ${
                    snapshot.isDraggingOver ? "border-violet-400 bg-violet-50 dark:bg-violet-900/20" : "border-border bg-white dark:bg-slate-800"
                  }`}
                >
                  {unorganized.length === 0 && !snapshot.isDraggingOver && (
                    <div className="py-8 text-center text-xs text-muted-foreground">All outputs are organized!</div>
                  )}
                  {unorganized.map((output, index) => (
                    <OutputCard key={output.id} output={output} index={index} />
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>

          {/* Projects */}
          <div className="flex-1">
            {projects.length === 0 ? (
              <div className="text-center py-20 border-2 border-dashed border-border rounded-2xl bg-white dark:bg-slate-800">
                <FolderOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <h3 className="font-semibold text-foreground mb-1">No projects yet</h3>
                <p className="text-sm text-muted-foreground mb-4">Create a project to organize your AI outputs</p>
                <button onClick={() => setShowNewProject(true)} className="px-4 py-2 rounded-xl bg-violet-600 text-white text-sm font-medium">
                  Create your first project
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map(project => {
                  const projectOutputs = getProjectOutputs(project.id);
                  const isOver = draggingOver === project.id;
                  return (
                    <div key={project.id} className={`bg-white dark:bg-slate-800 rounded-2xl border-2 transition-all ${isOver ? "border-violet-400 shadow-lg shadow-violet-100" : "border-border"}`}>
                      <div className={`h-2 rounded-t-2xl bg-gradient-to-r ${project.color || "from-violet-500 to-purple-600"}`} />
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2 group">
                          <button onClick={() => setSelectedProject(project)} className="flex-1 text-left">
                            <h3 className="font-semibold text-foreground hover:text-violet-600 transition-colors">{project.name}</h3>
                            {project.description && <p className="text-xs text-muted-foreground">{project.description}</p>}
                          </button>
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-muted-foreground">{projectOutputs.length} items</span>
                            <button
                              onClick={() => deleteProject.mutate(project.id)}
                              className="opacity-0 group-hover:opacity-100 ml-2 text-muted-foreground hover:text-red-500 transition-all"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <Droppable droppableId={project.id}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.droppableProps}
                              className={`min-h-20 rounded-xl border-2 border-dashed transition-colors p-2 space-y-2 ${
                                snapshot.isDraggingOver ? "border-violet-400 bg-violet-50 dark:bg-violet-900/20" : "border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/30"
                              }`}
                            >
                              {projectOutputs.length === 0 && !snapshot.isDraggingOver && (
                                <div className="py-4 text-center text-xs text-muted-foreground">Drop outputs here</div>
                              )}
                              {projectOutputs.map((output, index) => (
                                <OutputCard key={output.id} output={output} index={index} compact />
                              ))}
                              {provided.placeholder}
                            </div>
                          )}
                        </Droppable>
                        <button onClick={() => setSelectedProject(project)} className="mt-2 w-full flex items-center justify-center gap-1 text-xs text-muted-foreground hover:text-violet-600 transition-colors py-1">
                          Open project <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </DragDropContext>

      {showNewProject && (
        <NewProjectModal
          colors={PROJECT_COLORS}
          onClose={() => setShowNewProject(false)}
          onCreated={() => { setShowNewProject(false); qc.invalidateQueries({ queryKey: ["projects"] }); }}
        />
      )}
    </div>
  );
}

function OutputCard({ output, index, compact }) {
  const Icon = TOOL_ICONS[output.tool] || FileText;
  return (
    <Draggable draggableId={output.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`flex items-center gap-2 bg-white dark:bg-slate-800 rounded-lg border border-border px-3 py-2 select-none ${
            snapshot.isDragging ? "shadow-lg ring-2 ring-violet-400 opacity-90" : "hover:border-violet-200"
          }`}
        >
          <div {...provided.dragHandleProps} className="text-muted-foreground cursor-grab active:cursor-grabbing shrink-0">
            <GripVertical className="w-3.5 h-3.5" />
          </div>
          <div className="w-6 h-6 rounded-md bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center shrink-0">
            <Icon className="w-3 h-3 text-violet-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-foreground truncate">{output.title}</p>
            {!compact && <p className="text-xs text-muted-foreground">{output.tool}</p>}
          </div>
        </div>
      )}
    </Draggable>
  );
}