const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Copy, Settings2, Bug, RefreshCw, Sparkles } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import ApiKeyRequired from "@/components/ApiKeyRequired";
import SaveTemplateButton from "@/components/templates/SaveTemplateButton";
import UseTemplateButton from "@/components/templates/UseTemplateButton";

const LANGUAGES = ["Python", "JavaScript", "TypeScript", "Java", "C++", "Go", "Rust", "HTML/CSS", "SQL", "Swift", "Kotlin", "PHP"];
const MODES = [
  { id: "generate", label: "Generate", icon: "✨", desc: "Write code from scratch" },
  { id: "debug", label: "Debug", icon: "🐛", desc: "Find & fix issues" },
  { id: "explain", label: "Explain", icon: "📖", desc: "Understand code" },
  { id: "refactor", label: "Refactor", icon: "♻️", desc: "Improve existing code" },
  { id: "test", label: "Tests", icon: "🧪", desc: "Generate unit tests" },
];

export default function CodeGenerator() {
  const tool = getToolByPath("/code-generator");
  const [prompt, setPrompt] = useState("");
  const [lang, setLang] = useState("Python");
  const [mode, setMode] = useState("generate");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setResult("");
    const modePrompts = {
      generate: `Generate complete, production-ready ${lang} code for: "${prompt}". Include: well-structured code with proper error handling, inline comments explaining each section, example usage, and a brief explanation of the approach. Use best practices for ${lang}.`,
      debug: `Debug the following ${lang} code. Identify all bugs, explain each issue clearly, and provide the corrected code with explanations of what was fixed: "${prompt}"`,
      explain: `Explain the following ${lang} code in detail. Break down what each part does, explain the overall logic, identify any patterns or algorithms used, and note any potential improvements: "${prompt}"`,
      refactor: `Refactor the following ${lang} code for better readability, performance, and maintainability. Show the original, explain what was improved and why, then show the refactored version: "${prompt}"`,
      test: `Write comprehensive unit tests in ${lang} for: "${prompt}". Include edge cases, happy path, error scenarios. Use the most common testing framework for ${lang}.`,
    };
    const res = await db.integrations.Core.InvokeLLM({
      prompt: modePrompts[mode],
      model: "claude_sonnet_4_6",
    });
    setResult(res);
    setLoading(false);
  };

  const download = () => {
    const ext = {Python:"py",JavaScript:"js",TypeScript:"ts",Java:"java","C++":"cpp",Go:"go",Rust:"rs","HTML/CSS":"html"}[lang] || "txt";
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([result],{type:"text/plain"})); a.download = `code.${ext}`; a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          {/* Mode Selector */}
          <div className="flex gap-2 mb-3 flex-wrap">
            {MODES.map(m => (
              <button key={m.id} onClick={() => setMode(m.id)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 ${mode===m.id?"bg-cyan-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>
                <span>{m.icon}</span> {m.label}
              </button>
            ))}
          </div>
          {/* Language Selector */}
          <div className="flex flex-wrap gap-1.5 mb-3">
            {LANGUAGES.map(l => (
              <button key={l} onClick={() => setLang(l)} className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${lang===l?"bg-slate-800 dark:bg-slate-200 text-white dark:text-slate-900":"bg-white dark:bg-slate-800 border border-border text-muted-foreground"}`}>{l}</button>
            ))}
          </div>
          <div className="flex gap-2 mb-2">
            <UseTemplateButton tool="Code Generator" onSelect={setPrompt} />
            {prompt.trim() && <SaveTemplateButton tool="Code Generator" prompt={prompt} />}
          </div>
          <div className="flex gap-2 mb-4">
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={3}
              placeholder={mode === "generate" ? "Describe the code you want to create..." : mode === "debug" ? "Paste your buggy code here..." : mode === "explain" ? "Paste code to explain..." : mode === "refactor" ? "Paste code to refactor..." : "Describe what you want tests for..."}
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 resize-none" />
            <button onClick={generate} disabled={!prompt.trim() || loading} className="px-5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2 self-start py-3">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {MODES.find(m2 => m2.id === mode)?.label || "Run"}
            </button>
          </div>

          {result && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden">
              <div className="flex justify-end gap-2 p-3 border-b border-border flex-wrap">
                <SaveToProjectButton tool="Code Generator" title={`${lang} ${mode}: ${prompt.slice(0,50)}`} content={result} />
                <button onClick={() => navigator.clipboard.writeText(result)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs"><Copy className="w-3.5 h-3.5" /> Copy</button>
                <button onClick={download} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 text-white text-xs"><Download className="w-3.5 h-3.5" /> Download</button>
              </div>
              <div className="p-5 prose-output text-sm text-foreground leading-relaxed">
                <ReactMarkdown
                  components={{
                    code: ({inline, children}) => inline
                      ? <code className="bg-slate-100 dark:bg-slate-700 px-1 rounded text-xs font-mono">{children}</code>
                      : <pre className="bg-slate-900 text-green-400 p-4 rounded-xl overflow-x-auto text-xs font-mono whitespace-pre"><code>{children}</code></pre>
                  }}
                >{result}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}