import { useState, useRef } from "react";

import { Upload, FileDown, Loader2 } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";

const MODES = ["Text → PDF", "Images → PDF", "Word → PDF"];

export default function PdfTools() {
  const tool = getToolByPath("/pdf-tools");
  const [mode, setMode] = useState("Text → PDF");
  const [text, setText] = useState("");
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef();

  const handleFiles = (e) => setFiles(Array.from(e.target.files));

  const generate = async () => {
    setLoading(true);

    if (mode === "Text → PDF") {
      const html = `<!DOCTYPE html><html><head><style>body{font-family:Georgia,serif;max-width:750px;margin:60px auto;line-height:1.8;font-size:13pt;color:#1e293b;}p{margin-bottom:1em;}</style></head><body>${text.split('\n').map(l=>`<p>${l}</p>`).join('')}</body></html>`;
      const w = window.open("","_blank");
      w.document.write(html);
      w.document.close();
      w.focus();
      setTimeout(() => { w.print(); setLoading(false); }, 500);
      return;
    }

    if (mode === "Images → PDF") {
      const readers = files.map(f => new Promise(resolve => {
        const reader = new FileReader();
        reader.onload = e => resolve(e.target.result);
        reader.readAsDataURL(f);
      }));
      const dataUrls = await Promise.all(readers);
      const html = `<!DOCTYPE html><html><head><style>body{margin:0;background:#fff;}img{width:100%;display:block;page-break-after:always;}</style></head><body>${dataUrls.map(url=>`<img src="${url}" />`).join('')}</body></html>`;
      const w = window.open("","_blank");
      w.document.write(html);
      w.document.close();
      w.focus();
      setTimeout(() => { w.print(); setLoading(false); }, 500);
      return;
    }

    // Word → PDF: treat as text
    if (files.length > 0) {
      const text = await files[0].text().catch(() => "Unable to read file directly. Please copy-paste content.");
      const html = `<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;max-width:750px;margin:60px auto;line-height:1.8;font-size:12pt;}</style></head><body><pre style="white-space:pre-wrap">${text}</pre></body></html>`;
      const w = window.open("","_blank");
      w.document.write(html);
      w.document.close();
      w.focus();
      setTimeout(() => { w.print(); setLoading(false); }, 500);
    } else {
      setLoading(false);
    }
  };

  const acceptMap = { "Text → PDF": null, "Images → PDF": "image/*", "Word → PDF": ".doc,.docx,.txt" };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex flex-wrap gap-2 mb-4">
            {MODES.map(m => (
              <button key={m} onClick={() => setMode(m)} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${mode===m?"bg-red-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>{m}</button>
            ))}
          </div>

          {mode === "Text → PDF" ? (
            <textarea value={text} onChange={e => setText(e.target.value)} rows={8} placeholder="Type or paste your text here..."
              className="w-full px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none resize-none mb-4" />
          ) : (
            <div onClick={() => fileRef.current?.click()} className="border-2 border-dashed border-border rounded-2xl p-10 text-center cursor-pointer hover:border-red-400 transition-colors mb-4">
              <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm font-medium text-foreground">{files.length > 0 ? files.map(f=>f.name).join(", ") : "Click to select files"}</p>
              <p className="text-xs text-muted-foreground mt-1">{mode === "Images → PDF" ? "Select images" : "Select document"}</p>
              <input ref={fileRef} type="file" accept={acceptMap[mode]} multiple={mode === "Images → PDF"} onChange={handleFiles} className="hidden" />
            </div>
          )}

          <button onClick={generate} disabled={loading || (mode === "Text → PDF" ? !text.trim() : files.length === 0)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-500 to-orange-500 text-white text-sm font-semibold disabled:opacity-40">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
            Generate PDF
          </button>
        </div>
      </div>
    </div>
  );
}