const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { Key, Plus, Bell } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyTable from "@/components/devportal/ApiKeyTable";
import CreateKeyModal from "@/components/devportal/CreateKeyModal";
import NewKeyRevealModal from "@/components/devportal/NewKeyRevealModal";
import KeyDetailPanel from "@/components/devportal/KeyDetailPanel";
import AlertsPanel from "@/components/devportal/AlertsPanel";

export default function DevPortal() {
  const tool = getToolByPath("/dev-portal");
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newKeySecret, setNewKeySecret] = useState(null);
  const [selectedKey, setSelectedKey] = useState(null);
  const [showAlerts, setShowAlerts] = useState(false);

  const { data: keys = [], refetch } = useQuery({
    queryKey: ["api-keys"],
    queryFn: () => db.entities.ApiKey.list("-created_date"),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ["key-alerts"],
    queryFn: () => db.entities.KeyAlert.list("-created_date", 50),
  });

  const unreadAlerts = alerts.filter(a => !a.read).length;

  const handleCreated = (rawSecret, keyRecord) => {
    setNewKeySecret({ secret: rawSecret, record: keyRecord });
    refetch();
    qc.invalidateQueries({ queryKey: ["api-keys"] });
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-6xl mx-auto">

          {/* Header bar */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-foreground">API Key Management</h2>
              <p className="text-sm text-muted-foreground mt-0.5">Enterprise-grade key infrastructure with dual-token security</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowAlerts(true)}
                className="relative flex items-center gap-2 px-4 py-2 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm font-medium hover:border-violet-300 transition-colors"
              >
                <Bell className="w-4 h-4" />
                Alerts
                {unreadAlerts > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                    {unreadAlerts}
                  </span>
                )}
              </button>
              <button
                onClick={() => setShowCreate(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-semibold shadow-sm hover:opacity-90 transition-opacity"
              >
                <Plus className="w-4 h-4" />
                New API Key
              </button>
            </div>
          </div>

          {/* Stats bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            {[
              { label: "Total Keys", value: keys.length },
              { label: "Active", value: keys.filter(k => k.status === "active").length },
              { label: "Quarantined", value: keys.filter(k => k.status === "quarantined").length },
              { label: "Rotating", value: keys.filter(k => k.status === "rotating").length },
            ].map(stat => (
              <div key={stat.label} className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-4">
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Keys table */}
          <ApiKeyTable
            keys={keys}
            onSelect={setSelectedKey}
            onRefresh={() => qc.invalidateQueries({ queryKey: ["api-keys"] })}
          />

          {/* Empty state */}
          {keys.length === 0 && (
            <div className="text-center py-20">
              <Key className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-40" />
              <p className="font-semibold text-foreground">No API keys yet</p>
              <p className="text-sm text-muted-foreground mt-1">Create your first key to get started</p>
            </div>
          )}
        </div>
      </div>

      {showCreate && (
        <CreateKeyModal
          onClose={() => setShowCreate(false)}
          onCreated={handleCreated}
        />
      )}

      {newKeySecret && (
        <NewKeyRevealModal
          secret={newKeySecret.secret}
          record={newKeySecret.record}
          onClose={() => setNewKeySecret(null)}
        />
      )}

      {selectedKey && (
        <KeyDetailPanel
          apiKey={selectedKey}
          onClose={() => setSelectedKey(null)}
          onRefresh={() => qc.invalidateQueries({ queryKey: ["api-keys"] })}
        />
      )}

      {showAlerts && (
        <AlertsPanel
          alerts={alerts}
          onClose={() => setShowAlerts(false)}
          onRefresh={() => qc.invalidateQueries({ queryKey: ["key-alerts"] })}
        />
      )}
    </div>
  );
}