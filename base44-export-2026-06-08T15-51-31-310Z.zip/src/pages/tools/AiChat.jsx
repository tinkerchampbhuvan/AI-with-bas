const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useRef, useEffect } from "react";

import { Send, Loader2, MessageSquare, Lightbulb, PenLine, HelpCircle, Wrench, Trash2, Brain, Zap } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import ApiKeyRequired from "@/components/ApiKeyRequired";
import SaveTemplateButton from "@/components/templates/SaveTemplateButton";
import UseTemplateButton from "@/components/templates/UseTemplateButton";

const SUGGESTIONS = [
  { icon: Lightbulb, title: "Brainstorm ideas", desc: "Brainstorm 5 creative business ideas for a sustainable coffee shop." },
  { icon: PenLine, title: "Write something", desc: "Write a short, engaging LinkedIn post about staying productive while working remotely." },
  { icon: HelpCircle, title: "Explain a concept", desc: "Explain how machine learning works in simple terms a 10-year-old would understand." },
  { icon: Wrench, title: "Solve a problem", desc: "Help me plan a 7-day healthy meal prep on a $50 budget." },
];

const MODELS = [
  { id: "auto", label: "Auto", desc: "Fast & smart" },
  { id: "claude_sonnet_4_6", label: "Claude Sonnet", desc: "Advanced reasoning" },
  { id: "gpt_5_4", label: "GPT-4o", desc: "Balanced power" },
];

export default function AiChat() {
  const tool = getToolByPath("/ai-chat");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState("auto");
  const [systemPrompt, setSystemPrompt] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setMessages(prev => [...prev, { role: "user", content: msg }]);
    setInput("");
    setLoading(true);
    const history = [...messages, { role: "user", content: msg }]
      .map(m => `${m.role === "user" ? "User" : "AI"}: ${m.content}`).join("\n\n");
    const systemInstruction = systemPrompt ? `System instructions: ${systemPrompt}\n\n` : "";
    const params = { prompt: `You are a helpful, intelligent AI assistant. ${systemInstruction}\n\n${history}\n\nAI:` };
    if (model !== "auto") params.model = model;
    const res = await db.integrations.Core.InvokeLLM(params);
    setMessages(prev => [...prev, { role: "ai", content: res }]);
    setLoading(false);
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 py-6 tool-page-bg">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-6">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-200">
              <MessageSquare className="w-7 h-7 text-white" />
            </div>
            <div className="text-center">
              <h2 className="text-2xl font-bold text-foreground mb-1">How can I help you today?</h2>
              <p className="text-sm text-muted-foreground">Powered by AI — fast, smart, and always ready.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-xl w-full">
              {SUGGESTIONS.map((s, i) => (
                <button key={i} onClick={() => send(s.desc)} className="text-left p-4 bg-white dark:bg-slate-800 rounded-xl border border-border hover:border-violet-300 hover:shadow-sm transition-all">
                  <div className="flex items-start gap-3">
                    <s.icon className="w-4 h-4 text-violet-500 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-semibold text-sm text-foreground">{s.title}</div>
                      <div className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{s.desc}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm ${m.role === "user" ? "bg-violet-600 text-white rounded-tr-sm" : "bg-white dark:bg-slate-800 border border-border rounded-tl-sm"}`}>
                  {m.role === "user" ? m.content : (
                    <div className="prose-output">
                      <ReactMarkdown>{m.content}</ReactMarkdown>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-slate-800 border border-border rounded-2xl rounded-tl-sm px-4 py-3">
                  <div className="flex gap-1">
                    {[0,1,2].map(i => <div key={i} className="w-2 h-2 rounded-full bg-violet-400 animate-bounce" style={{animationDelay:`${i*150}ms`}} />)}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>
      <div className="px-4 py-3 bg-white dark:bg-slate-900 border-t border-border">
        {showSettings && (
          <div className="max-w-2xl mx-auto mb-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-border">
            <div className="flex gap-2 mb-2 flex-wrap">
              {MODELS.map(m => (
                <button key={m.id} onClick={() => setModel(m.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${model === m.id ? "bg-violet-600 text-white" : "border border-border bg-white dark:bg-slate-700"}`}>
                  {m.label} <span className="opacity-60">— {m.desc}</span>
                </button>
              ))}
            </div>
            <input value={systemPrompt} onChange={e => setSystemPrompt(e.target.value)}
              placeholder="System prompt (e.g. 'You are a senior software engineer')..."
              className="w-full px-3 py-2 rounded-lg border border-border text-xs bg-white dark:bg-slate-700 focus:outline-none" />
          </div>
        )}
        <div className="max-w-2xl mx-auto flex gap-2 mb-2 justify-between">
          <div className="flex gap-2">
            <button onClick={() => setShowSettings(!showSettings)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs transition-colors ${showSettings ? "bg-violet-600 text-white border-violet-600" : "bg-white dark:bg-slate-800"}`}>
              <Brain className="w-3.5 h-3.5" /> Model
            </button>
            <UseTemplateButton tool="AI Chat" onSelect={(p) => setInput(p)} />
            {input.trim() && <SaveTemplateButton tool="AI Chat" prompt={input} />}
          </div>
          <div className="flex gap-2">
            {messages.length > 0 && (
              <>
                <SaveToProjectButton tool="AI Chat" title={`Chat: ${messages[0]?.content?.slice(0,50) || "conversation"}`} content={messages.map(m => `${m.role === "user" ? "You" : "AI"}: ${m.content}`).join("\n\n")} />
                <button onClick={() => setMessages([])} className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-red-500">
                  <Trash2 className="w-3 h-3" /> Clear
                </button>
              </>
            )}
          </div>
        </div>
        <div className="max-w-2xl mx-auto flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Type your message..."
            className="flex-1 px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
          />
          <button onClick={() => send()} disabled={!input.trim() || loading} className="w-11 h-11 rounded-xl bg-violet-600 flex items-center justify-center disabled:opacity-40">
            {loading ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <Send className="w-4 h-4 text-white" />}
          </button>
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}