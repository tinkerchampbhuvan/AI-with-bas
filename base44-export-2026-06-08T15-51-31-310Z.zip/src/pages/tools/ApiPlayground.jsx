const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { KeyRound, Unlock, Lock, Loader2, Send, Image, MessageSquare, Mic, ShieldCheck, AlertTriangle, Copy, Check } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

const MODES = [
  { id: "chat", label: "AI Chat", icon: MessageSquare, color: "from-violet-500 to-purple-600" },
  { id: "image", label: "Image Gen", icon: Image, color: "from-pink-500 to-rose-500" },
  { id: "speech", label: "Text to Speech", icon: Mic, color: "from-purple-500 to-violet-500" },
];

export default function ApiPlayground() {
  const tool = getToolByPath("/api-playground");

  // Auth state
  const [apiKeyInput, setApiKeyInput] = useState("");
  const [validating, setValidating] = useState(false);
  const [authError, setAuthError] = useState("");
  const [authedKey, setAuthedKey] = useState(null); // the DB record

  // Playground state
  const [mode, setMode] = useState("chat");
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null); // { type, content }
  const [copied, setCopied] = useState(false);

  const validateKey = async () => {
    if (!apiKeyInput.trim()) return;
    setValidating(true);
    setAuthError("");
    try {
      const hash = await sha256(apiKeyInput.trim());
      // Find key by hash
      const keys = await db.entities.ApiKey.filter({ secret_hash: hash });
      if (!keys || keys.length === 0) {
        setAuthError("Invalid API key. Key not found.");
        setValidating(false);
        return;
      }
      const key = keys[0];
      if (key.status === "quarantined") {
        setAuthError("This key has been quarantined due to a security alert. Please generate a new key.");
        setValidating(false);
        return;
      }
      if (key.status === "revoked") {
        setAuthError("This key has been revoked and is no longer valid.");
        setValidating(false);
        return;
      }
      // Check scopes
      const scopes = key.scopes || [];
      if (!scopes.includes("read") && !scopes.includes("full")) {
        setAuthError("This key does not have the required 'read' or 'full' scope for the playground.");
        setValidating(false);
        return;
      }
      // Update request count
      await db.entities.ApiKey.update(key.id, {
        total_requests: (key.total_requests || 0) + 1,
        success_requests: (key.success_requests || 0) + 1,
      });
      setAuthedKey(key);
    } catch (e) {
      setAuthError("Validation failed. Please try again.");
    }
    setValidating(false);
  };

  const runCall = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setResult(null);

    // Update usage stats
    await db.entities.ApiKey.update(authedKey.id, {
      total_requests: (authedKey.total_requests || 0) + 1,
      success_requests: (authedKey.success_requests || 0) + 1,
    });

    try {
      if (mode === "chat") {
        const res = await db.integrations.Core.InvokeLLM({ prompt });
        setResult({ type: "text", content: res });
      } else if (mode === "image") {
        const res = await db.integrations.Core.GenerateImage({ prompt });
        setResult({ type: "image", content: res.url });
      } else if (mode === "speech") {
        const res = await db.integrations.Core.GenerateSpeech({ text: prompt });
        setResult({ type: "audio", content: res.url });
      }
    } catch (e) {
      setResult({ type: "error", content: "API call failed: " + e.message });
    }
    setLoading(false);
  };

  const copy = () => {
    if (result?.content) {
      navigator.clipboard.writeText(result.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const logout = () => {
    setAuthedKey(null);
    setApiKeyInput("");
    setResult(null);
    setPrompt("");
    setAuthError("");
  };

  // ── Auth wall ──
  if (!authedKey) {
    return (
      <div className="flex flex-col h-screen">
        <ToolHeader tool={tool} />
        <div className="flex-1 flex items-center justify-center tool-page-bg p-6">
          <div className="w-full max-w-md">
            <div className="bg-white dark:bg-slate-900 rounded-2xl border-2 border-border shadow-xl p-8">
              <div className="text-center mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Lock className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-xl font-bold text-foreground">API Playground</h2>
                <p className="text-sm text-muted-foreground mt-1">Paste your secret API key to authenticate and start making real AI calls.</p>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-foreground mb-1">Your Secret API Key</label>
                  <input
                    type="password"
                    value={apiKeyInput}
                    onChange={e => setApiKeyInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && validateKey()}
                    placeholder="sk_live_••••••••••••••••••••"
                    className="w-full px-3 py-2.5 rounded-xl border border-border bg-slate-50 dark:bg-slate-800 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-violet-400"
                  />
                </div>

                {authError && (
                  <div className="flex items-start gap-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-3 text-xs text-red-600 dark:text-red-400">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    {authError}
                  </div>
                )}

                <button
                  onClick={validateKey}
                  disabled={!apiKeyInput.trim() || validating}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-slate-700 to-slate-900 text-white text-sm font-semibold disabled:opacity-40 flex items-center justify-center gap-2"
                >
                  {validating ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                  {validating ? "Validating…" : "Authenticate"}
                </button>
              </div>

              <p className="text-[11px] text-muted-foreground text-center mt-4">
                Don't have a key? Generate one in the <a href="/dev-portal" className="text-violet-600 underline">Developer Portal</a>.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ── Authenticated Playground ──
  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">

          {/* Auth badge */}
          <div className="flex items-center justify-between mb-6 bg-white dark:bg-slate-800 rounded-2xl border border-border px-4 py-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4 text-green-600" />
              </div>
              <div>
                <div className="text-sm font-semibold text-foreground">Authenticated as <span className="text-violet-600">{authedKey.name}</span></div>
                <div className="text-xs font-mono text-muted-foreground">{authedKey.key_id} · scopes: {authedKey.scopes?.join(", ")}</div>
              </div>
            </div>
            <button onClick={logout} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <Lock className="w-3.5 h-3.5" /> Sign out
            </button>
          </div>

          {/* Mode tabs */}
          <div className="flex gap-2 mb-4 flex-wrap">
            {MODES.map(m => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => { setMode(m.id); setResult(null); setPrompt(""); }}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border-2 transition-colors ${
                    mode === m.id
                      ? "border-violet-500 bg-violet-50 dark:bg-violet-900/30 text-violet-700 dark:text-violet-300"
                      : "border-border bg-white dark:bg-slate-800 text-foreground"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {m.label}
                </button>
              );
            })}
          </div>

          {/* Input */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-4 mb-4">
            <label className="block text-xs font-semibold text-foreground mb-2">
              {mode === "chat" ? "Your prompt" : mode === "image" ? "Image description" : "Text to speak"}
            </label>
            <textarea
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              rows={3}
              placeholder={
                mode === "chat" ? "Ask anything…"
                : mode === "image" ? "A futuristic cityscape at sunset…"
                : "Enter the text you want converted to speech…"
              }
              className="w-full px-3 py-2.5 rounded-xl border border-border bg-slate-50 dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-violet-400 resize-none"
            />
            <div className="flex justify-between items-center mt-3">
              <div className="text-xs text-muted-foreground font-mono">
                Key: <span className="text-foreground">{authedKey.secret_masked}</span>
              </div>
              <button
                onClick={runCall}
                disabled={!prompt.trim() || loading}
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-semibold disabled:opacity-40"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                {loading ? "Running…" : "Run API Call"}
              </button>
            </div>
          </div>

          {/* Result */}
          {result && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-slate-50 dark:bg-slate-900/50">
                <span className="text-xs font-semibold text-foreground">Response</span>
                {result.type === "text" && (
                  <button onClick={copy} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                    {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? "Copied" : "Copy"}
                  </button>
                )}
              </div>
              <div className="p-5">
                {result.type === "text" && (
                  <div className="prose-output text-sm text-foreground leading-relaxed">
                    <ReactMarkdown>{result.content}</ReactMarkdown>
                  </div>
                )}
                {result.type === "image" && (
                  <img src={result.content} alt="Generated" className="rounded-xl w-full max-w-md mx-auto block" />
                )}
                {result.type === "audio" && (
                  <audio controls src={result.content} className="w-full" />
                )}
                {result.type === "error" && (
                  <div className="text-red-500 text-sm">{result.content}</div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}