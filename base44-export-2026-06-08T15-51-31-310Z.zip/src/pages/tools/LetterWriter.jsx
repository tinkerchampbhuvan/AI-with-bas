const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Copy, Printer, Languages } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import ApiKeyRequired from "@/components/ApiKeyRequired";
import SaveTemplateButton from "@/components/templates/SaveTemplateButton";
import UseTemplateButton from "@/components/templates/UseTemplateButton";

const TYPES = ["Formal Business", "Informal", "Cover Letter", "Resignation", "Complaint", "Thank You", "Invitation", "Apology", "Reference", "Partnership Proposal"];
const TONES = ["Professional", "Friendly", "Persuasive", "Empathetic", "Assertive", "Humble"];
const LANGUAGES_LIST = ["English", "Spanish", "French", "German", "Portuguese", "Hindi", "Arabic", "Japanese", "Chinese"];

export default function LetterWriter() {
  const tool = getToolByPath("/letter-writer");
  const [prompt, setPrompt] = useState("");
  const [type, setType] = useState("Formal Business");
  const [tone, setTone] = useState("Professional");
  const [language, setLanguage] = useState("English");
  const [letter, setLetter] = useState("");
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState("preview");

  const write = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setLetter("");
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Write a ${tone.toLowerCase()}-toned ${type} letter in ${language} for: "${prompt}".
      Use proper letter format: date, sender address placeholder, recipient address placeholder, salutation, well-structured body paragraphs, closing, and signature placeholder.
      Make it complete, polished, and ready to use. Tone should be ${tone.toLowerCase()}. Write entirely in ${language}.`,
    });
    setLetter(res);
    setLoading(false);
  };

  const downloadTxt = () => {
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([letter],{type:"text/plain"})); a.download = "letter.txt"; a.click();
  };

  const downloadHtml = () => {
    const html = `<!DOCTYPE html><html><head><style>body{font-family:Georgia,serif;max-width:700px;margin:60px auto;padding:40px;line-height:1.8;font-size:14pt;}p{margin-bottom:1rem;}</style></head><body>${letter.split('\n').map(l=>`<p>${l}</p>`).join('')}</body></html>`;
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([html],{type:"text/html"})); a.download = "letter.html"; a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          {/* Type */}
          <div className="flex flex-wrap gap-1.5 mb-2">
            {TYPES.map(t => (
              <button key={t} onClick={() => setType(t)} className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${type===t?"bg-green-600 text-white":"bg-white dark:bg-slate-800 border border-border text-foreground"}`}>{t}</button>
            ))}
          </div>
          {/* Tone + Language */}
          <div className="flex gap-2 mb-3 flex-wrap">
            <div>
              <p className="text-xs text-muted-foreground mb-1 font-medium">Tone</p>
              <div className="flex gap-1.5 flex-wrap">
                {TONES.map(t => (
                  <button key={t} onClick={() => setTone(t)} className={`px-2.5 py-1 rounded-lg text-xs font-medium ${tone===t?"bg-emerald-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>{t}</button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1 font-medium">Language</p>
              <select value={language} onChange={e => setLanguage(e.target.value)} className="px-3 py-1 rounded-lg border border-border text-xs bg-white dark:bg-slate-800 focus:outline-none">
                {LANGUAGES_LIST.map(l => <option key={l}>{l}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-2 mb-2">
            <UseTemplateButton tool="Letter Writer" onSelect={setPrompt} />
            {prompt.trim() && <SaveTemplateButton tool="Letter Writer" prompt={prompt} />}
          </div>
          <div className="flex gap-2 mb-4">
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={2} placeholder="Describe what the letter is about…"
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-green-400 resize-none" />
            <button onClick={write} disabled={!prompt.trim() || loading} className="px-5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2 self-start py-3">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Write
            </button>
          </div>

          {letter && (
            <>
              <div className="flex flex-wrap gap-2 mb-3">
                {["preview","raw"].map(v => (
                  <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${view===v?"bg-violet-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>
                    {v === "preview" ? "Letter Preview" : "Raw Text"}
                  </button>
                ))}
                <SaveToProjectButton tool="Letter Writer" title={`${type}: ${prompt.slice(0,50)}`} content={letter} />
                <button onClick={() => navigator.clipboard.writeText(letter)} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5"><Copy className="w-3.5 h-3.5" /> Copy</button>
                <button onClick={() => window.print()} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5"><Printer className="w-3.5 h-3.5" /> Print</button>
                <button onClick={downloadTxt} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> .txt</button>
                <button onClick={downloadHtml} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-green-600 text-white flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> .html</button>
              </div>
              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-8">
                {view === "preview" ? (
                  <div className="prose-output text-sm text-foreground leading-relaxed whitespace-pre-wrap font-serif">{letter}</div>
                ) : (
                  <pre className="text-xs text-foreground whitespace-pre-wrap font-mono">{letter}</pre>
                )}
              </div>
            </>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}