const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Sparkles, Download } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";

export default function ResumeBuilder() {
  const tool = getToolByPath("/resume-builder");
  const [aiPrompt, setAiPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [resume, setResume] = useState({
    fullName: "", title: "", email: "", phone: "", location: "",
    summary: "", experience: "", education: "", skills: "",
  });

  const autoFill = async () => {
    if (!aiPrompt.trim() || loading) return;
    setLoading(true);
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Based on: "${aiPrompt}", generate a professional resume. Return JSON.`,
      response_json_schema: {
        type: "object",
        properties: {
          fullName: { type: "string" },
          title: { type: "string" },
          email: { type: "string" },
          phone: { type: "string" },
          location: { type: "string" },
          summary: { type: "string" },
          experience: { type: "string" },
          education: { type: "string" },
          skills: { type: "string" },
        }
      }
    });
    setResume(res);
    setLoading(false);
  };

  const downloadPdf = () => {
    const html = `<!DOCTYPE html><html><head><style>
body{font-family:Arial,sans-serif;max-width:800px;margin:0 auto;padding:40px;color:#1e293b;}
h1{font-size:28px;margin:0;}h2{font-size:13px;color:#7c3aed;font-weight:500;margin:0 0 4px;}
.title{color:#64748b;font-size:15px;margin:4px 0;}
.contact{color:#475569;font-size:12px;margin:8px 0;}
.section{margin-top:20px;padding-top:12px;border-top:1px solid #e2e8f0;}
.section h3{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin:0 0 8px;}
p{font-size:13px;line-height:1.6;margin:0;}
</style></head><body>
<h1>${resume.fullName}</h1>
<div class="title">${resume.title}</div>
<div class="contact">${resume.email} | ${resume.phone} | ${resume.location}</div>
${resume.summary ? `<div class="section"><h3>Summary</h3><p>${resume.summary}</p></div>` : ""}
${resume.experience ? `<div class="section"><h3>Experience</h3><p style="white-space:pre-line">${resume.experience}</p></div>` : ""}
${resume.education ? `<div class="section"><h3>Education</h3><p style="white-space:pre-line">${resume.education}</p></div>` : ""}
${resume.skills ? `<div class="section"><h3>Skills</h3><p>${resume.skills}</p></div>` : ""}
</body></html>`;
    const w = window.open("", "_blank");
    w.document.write(html);
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 500);
  };

  const fields = [
    { key: "fullName", label: "Full Name", half: true },
    { key: "title", label: "Professional Title", half: true },
    { key: "email", label: "Email", half: true },
    { key: "phone", label: "Phone", half: true },
    { key: "location", label: "Location", full: true },
    { key: "summary", label: "Summary", textarea: true },
    { key: "experience", label: "Experience", textarea: true },
    { key: "education", label: "Education", textarea: true },
    { key: "skills", label: "Skills", full: true },
  ];

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          {/* AI Autofill */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-4 mb-5">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-violet-500" />
              <span className="text-sm font-semibold text-foreground">AI Auto-fill</span>
            </div>
            <textarea value={aiPrompt} onChange={e => setAiPrompt(e.target.value)} rows={2}
              placeholder="Hi, I am a TinkerChamp and change-maker, my name is 'AIM.'"
              className="w-full px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-700 text-sm focus:outline-none resize-none mb-2" />
            <button onClick={autoFill} disabled={!aiPrompt.trim() || loading} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500 to-purple-600 text-white text-sm font-semibold disabled:opacity-40">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              Generate with AI
            </button>
          </div>

          {/* Form */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-6">
            <div className="grid grid-cols-2 gap-4">
              {fields.map(f => (
                <div key={f.key} className={f.textarea || f.full ? "col-span-2" : ""}>
                  <label className="block text-xs font-medium text-muted-foreground mb-1 capitalize">{f.label}</label>
                  {f.textarea ? (
                    <textarea value={resume[f.key]} onChange={e => setResume({...resume,[f.key]:e.target.value})} rows={3}
                      className="w-full px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-700 text-sm focus:outline-none resize-none" />
                  ) : (
                    <input value={resume[f.key]} onChange={e => setResume({...resume,[f.key]:e.target.value})}
                      className="w-full px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-700 text-sm focus:outline-none" />
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-center mt-6">
              <button onClick={downloadPdf} className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold">
                <Download className="w-4 h-4" /> Download PDF
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}