const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Monitor, Smartphone, Tablet, ExternalLink, Download, Code } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyRequired from "@/components/ApiKeyRequired";

export default function WebsiteBuilder() {
  const tool = getToolByPath("/website-builder");
  const [prompt, setPrompt] = useState("");
  const [html, setHtml] = useState("");
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState("preview");
  const [device, setDevice] = useState("desktop");

  const build = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setHtml("");

    // First, gather real-world info and image ideas from the internet
    const researchRes = await db.integrations.Core.InvokeLLM({
      prompt: `Research the following topic thoroughly for building a website: "${prompt}".
      Return a JSON object with:
      - title: the website's main title
      - tagline: a compelling one-line tagline
      - about: 2-3 sentences of real, accurate factual information about this topic
      - sections: array of 3-4 section objects, each with { heading: string, content: string (2-3 sentences of real info) }
      - imageQueries: array of 5 specific descriptive search queries for Unsplash images (e.g. "modern office workspace", "technology circuit board blue")
      - primaryColor: a hex color that fits the topic
      - accentColor: a complementary accent hex color`,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          tagline: { type: "string" },
          about: { type: "string" },
          sections: { type: "array", items: { type: "object", properties: { heading: { type: "string" }, content: { type: "string" } } } },
          imageQueries: { type: "array", items: { type: "string" } },
          primaryColor: { type: "string" },
          accentColor: { type: "string" },
        }
      }
    });

    // Build Unsplash image URLs from the queries
    const imageUrls = (researchRes.imageQueries || []).map(
      (q, i) => `https://source.unsplash.com/800x500/?${encodeURIComponent(q)}&sig=${i}`
    );

    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Generate a complete, stunning, production-quality single-file HTML website using this REAL researched data:

TOPIC: ${prompt}
TITLE: ${researchRes.title}
TAGLINE: ${researchRes.tagline}
ABOUT: ${researchRes.about}
SECTIONS: ${JSON.stringify(researchRes.sections)}
PRIMARY COLOR: ${researchRes.primaryColor || "#4f46e5"}
ACCENT COLOR: ${researchRes.accentColor || "#06b6d4"}
IMAGE URLS (use these real images): ${imageUrls.join(", ")}

Requirements:
- Use ALL the real researched content above — do NOT make up generic placeholder text
- Include a stunning hero section with the first image as background
- Use the provided image URLs for <img> tags and background images throughout the site
- Modern design: smooth gradients, glassmorphism cards, subtle animations with CSS keyframes
- Full navigation bar with smooth scroll links
- Multiple content sections using the provided headings and content
- A footer with copyright
- Fully responsive with mobile hamburger menu
- Include Google Fonts (Inter or similar)
- Use the provided primary and accent colors throughout
- Return ONLY complete HTML starting with <!DOCTYPE html>, nothing else`,
    });

    const match = res.match(/<!DOCTYPE html[\s\S]*<\/html>/i) || res.match(/<html[\s\S]*<\/html>/i);
    setHtml(match ? match[0] : res);
    setLoading(false);
  };

  const downloadHtml = () => {
    const blob = new Blob([html], { type: "text/html" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "website.html";
    a.click();
  };

  const deviceWidths = { desktop: "100%", tablet: "768px", mobile: "375px" };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 mb-4">
            <input
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              onKeyDown={e => e.key === "Enter" && build()}
              placeholder="Make a website on AI..."
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <button onClick={build} disabled={!prompt.trim() || loading} className="px-5 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {loading ? "Building..." : "Build"}
            </button>
          </div>

          {loading && (
            <div className="flex flex-col items-center justify-center py-16 gap-4 text-center">
              <Loader2 className="w-10 h-10 animate-spin text-blue-500" />
              <p className="text-sm font-medium text-foreground">Researching the web for real content & images…</p>
              <p className="text-xs text-muted-foreground">This may take 15–30 seconds for a fully realistic site</p>
            </div>
          )}

          {html && !loading && (
            <>
              <div className="flex flex-wrap gap-2 mb-3">
                <button onClick={() => setView("preview")} className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 ${view === "preview" ? "bg-violet-600 text-white" : "bg-white dark:bg-slate-800 border border-border"}`}>
                  <Monitor className="w-3.5 h-3.5" /> Preview
                </button>
                <button onClick={() => setView("code")} className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 ${view === "code" ? "bg-violet-600 text-white" : "bg-white dark:bg-slate-800 border border-border"}`}>
                  <Code className="w-3.5 h-3.5" /> Source Code
                </button>
                {["desktop","tablet","mobile"].map(d => (
                  <button key={d} onClick={() => setDevice(d)} className={`px-3 py-1.5 rounded-lg text-xs font-medium ${device === d && view === "preview" ? "bg-slate-700 text-white" : "bg-white dark:bg-slate-800 border border-border"}`}>
                    {d === "desktop" ? <Monitor className="w-3.5 h-3.5" /> : d === "tablet" ? <Tablet className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
                  </button>
                ))}
                <button onClick={() => { const w = window.open(); w.document.write(html); }} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5">
                  <ExternalLink className="w-3.5 h-3.5" /> New Tab
                </button>
                <button onClick={downloadHtml} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-600 text-white flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5" /> Download HTML
                </button>
              </div>
              {view === "preview" ? (
                <div className="flex justify-center bg-slate-200 dark:bg-slate-700 rounded-xl p-3" style={{minHeight:"400px"}}>
                  <iframe
                    srcDoc={html}
                    style={{ width: deviceWidths[device], height: "500px", border: "none", borderRadius: "8px", background: "#fff", transition: "width 0.3s" }}
                    title="preview"
                  />
                </div>
              ) : (
                <pre className="bg-slate-900 text-green-400 p-4 rounded-xl text-xs overflow-x-auto max-h-[500px]">{html}</pre>
              )}
            </>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}