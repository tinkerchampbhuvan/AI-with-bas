const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Play, Download } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyRequired from "@/components/ApiKeyRequired";

const VOICES = [
  { label: "Default", value: "river" },
  { label: "UK English", value: "storm" },
  { label: "French", value: "honey" },
  { label: "Spanish", value: "sunny" },
  { label: "German", value: "spark" },
  { label: "Hindi", value: "river" },
];

export default function VoiceGenerator() {
  const tool = getToolByPath("/voice-generator");
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("river");
  const [audioUrl, setAudioUrl] = useState("");
  const [loading, setLoading] = useState(false);

  const speak = async () => {
    if (!text.trim() || loading) return;
    setLoading(true);
    setAudioUrl("");
    const res = await db.integrations.Core.GenerateSpeech({ text, voice });
    setAudioUrl(res.url);
    setLoading(false);
  };

  const downloadText = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
    a.download = "speech-text.txt";
    a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-4">
            <label className="block text-sm font-medium text-foreground mb-2">Voice</label>
            <div className="flex flex-wrap gap-2">
              {VOICES.map(v => (
                <button key={v.value + v.label} onClick={() => setVoice(v.value)}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${voice === v.value && v.label === VOICES.find(x => x.value === voice)?.label ? "bg-violet-600 text-white" : "bg-white dark:bg-slate-800 border border-border"}`}>
                  {v.label}
                </button>
              ))}
            </div>
          </div>

          <textarea value={text} onChange={e => setText(e.target.value)} rows={4}
            placeholder="Hi my self Bhuvan..."
            className="w-full px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400 resize-none mb-4" />

          <div className="flex gap-3">
            <button onClick={speak} disabled={!text.trim() || loading} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-violet-600 text-white text-sm font-semibold disabled:opacity-40">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
              {loading ? "Generating..." : "Speak"}
            </button>
            <button onClick={downloadText} className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm font-medium">
              <Download className="w-4 h-4" /> Download Text
            </button>
          </div>

          {audioUrl && (
            <div className="mt-6 bg-white dark:bg-slate-800 rounded-2xl border border-border p-4">
              <p className="text-sm font-medium text-foreground mb-3">Your Audio</p>
              <audio controls src={audioUrl} className="w-full" />
              <div className="mt-3">
                <a href={audioUrl} download="speech.mp3" className="flex items-center gap-2 text-sm text-violet-600 hover:underline">
                  <Download className="w-4 h-4" /> Download MP3
                </a>
              </div>
            </div>
          )}

          <p className="mt-4 text-xs text-muted-foreground">Uses AI-powered text-to-speech synthesis.</p>
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}