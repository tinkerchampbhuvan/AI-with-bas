const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Sparkles, Plus, Trash2, Copy, ExternalLink } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";

export default function FormGenerator() {
  const tool = getToolByPath("/form-generator");
  const [prompt, setPrompt] = useState("");
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(false);
  const [script, setScript] = useState("");

  const generate = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setForm(null);
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Create a Google Form for: "${prompt}". Return JSON with title and questions array.`,
      response_json_schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          questions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                label: { type: "string" },
                type: { type: "string" },
                options: { type: "string" }
              }
            }
          }
        }
      }
    });
    setForm(res);
    generateScript(res);
    setLoading(false);
  };

  const generateScript = (f) => {
    const questions = (f.questions || []).map(q => {
      if (q.type === "Short" || q.type === "Paragraph") return `form.addTextItem().setTitle('${q.label}');`;
      if (q.type === "Multiple") return `form.addMultipleChoiceItem().setTitle('${q.label}').setChoiceValues([${(q.options||"").split(",").map(o=>`'${o.trim()}'`).join(",")}]);`;
      if (q.type === "Checkbox") return `form.addCheckboxItem().setTitle('${q.label}').setChoiceValues([${(q.options||"").split(",").map(o=>`'${o.trim()}'`).join(",")}]);`;
      return `form.addTextItem().setTitle('${q.label}');`;
    }).join("\n  ");
    setScript(`function createForm() {\n  var form = FormApp.create('${f.title}');\n  ${questions}\n  Logger.log('URL: ' + form.getEditUrl());\n}`);
  };

  const updateQuestion = (i, key, val) => {
    const q = [...form.questions]; q[i] = {...q[i],[key]:val};
    const updated = {...form, questions: q};
    setForm(updated);
    generateScript(updated);
  };

  const removeQuestion = (i) => {
    const updated = {...form, questions: form.questions.filter((_,idx)=>idx!==i)};
    setForm(updated);
    generateScript(updated);
  };

  const addQuestion = () => {
    const updated = {...form, questions: [...form.questions, {label:"New Question",type:"Short",options:""}]};
    setForm(updated);
    generateScript(updated);
  };

  const TYPES = ["Short","Paragraph","Multiple","Checkbox","Dropdown"];

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 mb-6">
            <input value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => e.key === "Enter" && generate()}
              placeholder="make a common registration form..."
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            <button onClick={generate} disabled={!prompt.trim() || loading} className="px-5 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              <Sparkles className="w-4 h-4" /> Generate
            </button>
          </div>

          {form && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-5 mb-4">
              <h2 className="font-bold text-foreground text-lg mb-4">{form.title}</h2>
              <div className="space-y-3">
                {form.questions?.map((q, i) => (
                  <div key={i} className="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-700 rounded-xl">
                    <input value={q.label} onChange={e => updateQuestion(i,"label",e.target.value)}
                      className="flex-1 bg-white dark:bg-slate-600 border border-border rounded-lg px-3 py-1.5 text-sm focus:outline-none" />
                    <select value={q.type} onChange={e => updateQuestion(i,"type",e.target.value)}
                      className="bg-white dark:bg-slate-600 border border-border rounded-lg px-2 py-1.5 text-xs focus:outline-none">
                      {TYPES.map(t => <option key={t}>{t}</option>)}
                    </select>
                    <button onClick={() => removeQuestion(i)} className="text-red-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                  </div>
                ))}
                <button onClick={addQuestion} className="flex items-center gap-1.5 text-sm text-teal-600 hover:text-teal-700">
                  <Plus className="w-4 h-4" /> Add question
                </button>
              </div>
            </div>
          )}

          {script && (
            <div className="bg-slate-900 rounded-2xl p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold text-slate-300">Google Apps Script (creates the form)</span>
                <button onClick={() => navigator.clipboard.writeText(script)} className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-teal-600 text-white text-xs">
                  <Copy className="w-3 h-3" /> Copy
                </button>
              </div>
              <pre className="text-green-400 text-xs overflow-x-auto whitespace-pre-wrap">{script}</pre>
              <p className="text-xs text-slate-400 mt-3">
                Open <a href="https://script.google.com" target="_blank" rel="noreferrer" className="text-blue-400 underline">script.google.com</a>, paste the code, run <code className="text-yellow-300">createForm()</code>, then check the log for the form URL.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}