const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Wand2, RefreshCw } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyRequired from "@/components/ApiKeyRequired";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import SaveTemplateButton from "@/components/templates/SaveTemplateButton";
import UseTemplateButton from "@/components/templates/UseTemplateButton";

const STYLES = [
  { id: "", label: "None" },
  { id: "photorealistic, DSLR quality, 8K", label: "📷 Photo" },
  { id: "digital art, vibrant, detailed illustration", label: "🎨 Digital Art" },
  { id: "oil painting, classical art style", label: "🖼 Oil Paint" },
  { id: "anime style, Studio Ghibli inspired", label: "🌸 Anime" },
  { id: "cinematic, movie still, dramatic lighting", label: "🎬 Cinematic" },
  { id: "minimalist, flat design, simple shapes", label: "⬜ Minimal" },
  { id: "watercolor painting, soft edges, artistic", label: "💧 Watercolor" },
  { id: "3D render, Blender, octane render", label: "🧊 3D Render" },
  { id: "sketch, pencil drawing, hand-drawn", label: "✏️ Sketch" },
];

const MOODS = ["", "golden hour", "dark moody", "vibrant colorful", "black and white", "neon lights", "foggy misty", "warm cozy"];

export default function ImageCreator() {
  const tool = getToolByPath("/image-creator");
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("");
  const [mood, setMood] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  const buildFullPrompt = () => {
    const parts = [prompt.trim()];
    if (style) parts.push(style);
    if (mood) parts.push(mood);
    return parts.join(", ");
  };

  const generate = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    const fullPrompt = buildFullPrompt();
    const res = await db.integrations.Core.GenerateImage({ prompt: fullPrompt });
    setImageUrl(res.url);
    setHistory(prev => [{ url: res.url, prompt: fullPrompt }, ...prev.slice(0, 5)]);
    setLoading(false);
  };

  const download = () => {
    const a = document.createElement("a");
    a.href = imageUrl;
    a.download = "ai-image.png";
    a.target = "_blank";
    a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-border p-4 mb-4">
            <div className="flex gap-2 mb-3">
              <UseTemplateButton tool="Image Creator" onSelect={setPrompt} />
              {prompt.trim() && <SaveTemplateButton tool="Image Creator" prompt={prompt} />}
            </div>
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={2}
              placeholder="Describe your image… e.g. 'A futuristic city at sunset with flying cars'"
              className="w-full px-4 py-3 rounded-xl border border-border bg-slate-50 dark:bg-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-pink-400 resize-none mb-3" />

            <div className="mb-2">
              <p className="text-xs font-semibold text-muted-foreground mb-1.5">Style</p>
              <div className="flex flex-wrap gap-1.5">
                {STYLES.map(s => (
                  <button key={s.id} onClick={() => setStyle(s.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${style===s.id?"bg-pink-500 text-white":"bg-slate-100 dark:bg-slate-700 text-muted-foreground hover:bg-slate-200"}`}>
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-3">
              <p className="text-xs font-semibold text-muted-foreground mb-1.5">Mood / Lighting</p>
              <div className="flex flex-wrap gap-1.5">
                {MOODS.map(m => (
                  <button key={m} onClick={() => setMood(m)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${mood===m?"bg-rose-500 text-white":"bg-slate-100 dark:bg-slate-700 text-muted-foreground hover:bg-slate-200"}`}>
                    {m || "None"}
                  </button>
                ))}
              </div>
            </div>

            {(style || mood) && (
              <div className="bg-slate-50 dark:bg-slate-700 rounded-lg px-3 py-2 mb-3">
                <p className="text-xs text-muted-foreground"><span className="font-semibold">Full prompt:</span> {buildFullPrompt()}</p>
              </div>
            )}

            <button onClick={generate} disabled={!prompt.trim() || loading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center justify-center gap-2">
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating…</> : <><Wand2 className="w-4 h-4" /> Generate Image</>}
            </button>
          </div>

          {imageUrl && !loading && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden mb-4">
              <img src={imageUrl} alt={prompt} className="w-full object-contain" />
              <div className="p-4 flex gap-2 justify-center flex-wrap">
                <SaveToProjectButton tool="Image Creator" title={`Image: ${prompt.slice(0,50)}`} content={prompt} imageUrl={imageUrl} />
                <button onClick={generate} className="flex items-center gap-2 px-4 py-2 rounded-xl border-2 border-border text-sm font-medium hover:border-pink-300">
                  <RefreshCw className="w-4 h-4" /> Regenerate
                </button>
                <button onClick={download} className="flex items-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white text-sm font-semibold">
                  <Download className="w-4 h-4" /> Download
                </button>
              </div>
            </div>
          )}

          {history.length > 1 && (
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">Recent Generations</p>
              <div className="grid grid-cols-3 gap-2">
                {history.slice(1).map((h, i) => (
                  <button key={i} onClick={() => setImageUrl(h.url)} className="rounded-xl overflow-hidden border-2 border-border hover:border-pink-300 transition-colors">
                    <img src={h.url} alt={h.prompt} className="w-full aspect-square object-cover" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}