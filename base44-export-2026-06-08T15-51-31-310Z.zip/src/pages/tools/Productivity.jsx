const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Copy } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyRequired from "@/components/ApiKeyRequired";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";

const MODES = ["Summarize", "Notes", "Todos"];

export default function Productivity() {
  const tool = getToolByPath("/productivity");
  const [mode, setMode] = useState("Summarize");
  const [prompt, setPrompt] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const go = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setResult("");
    const instructions = {
      Summarize: `Summarize the following clearly and concisely with key takeaways: "${prompt}"`,
      Notes: `Create well-structured study/reference notes from: "${prompt}". Include headings, bullet points, key concepts.`,
      Todos: `Create a clear, actionable to-do list from: "${prompt}". Number each task, group related tasks.`,
    };
    const res = await db.integrations.Core.InvokeLLM({ prompt: instructions[mode] });
    setResult(res);
    setLoading(false);
  };

  const download = () => {
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([result],{type:"text/plain"})); a.download = `${mode.toLowerCase()}.txt`; a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 mb-3">
            {MODES.map(m => (
              <button key={m} onClick={() => setMode(m)} className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${mode===m?"bg-violet-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>{m}</button>
            ))}
          </div>
          <div className="flex gap-2 mb-4">
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={3}
              placeholder={mode === "Summarize" ? "Explain AI..." : mode === "Notes" ? "Paste text to create notes..." : "Describe a project or goal..."}
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-lime-400 resize-none" />
            <button onClick={go} disabled={!prompt.trim() || loading} className="px-5 rounded-xl bg-gradient-to-r from-lime-500 to-green-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2 self-start py-3">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Go
            </button>
          </div>

          {result && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden">
              <div className="flex justify-end gap-2 p-3 border-b border-border flex-wrap">
                <SaveToProjectButton tool="Productivity" title={`${mode}: ${prompt.slice(0,50)}`} content={result} />
                <button onClick={() => navigator.clipboard.writeText(result)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs"><Copy className="w-3.5 h-3.5" /> Copy</button>
                <button onClick={download} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-lime-500 text-white text-xs"><Download className="w-3.5 h-3.5" /> Download</button>
              </div>
              <div className="p-5 prose-output text-sm text-foreground leading-relaxed">
                <ReactMarkdown>{result}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}