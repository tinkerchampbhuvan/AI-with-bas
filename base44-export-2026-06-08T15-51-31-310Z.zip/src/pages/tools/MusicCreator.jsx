const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Copy, Music } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";

const GENRES = ["Pop","Rock","Jazz","Classical","Electronic","Hip-Hop","Lo-Fi","Ambient","Country"];
const MOODS = ["Happy","Sad","Energetic","Calm","Dark","Romantic","Epic","Chill"];

export default function MusicCreator() {
  const tool = getToolByPath("/music-creator");
  const [genre, setGenre] = useState("Lo-Fi");
  const [mood, setMood] = useState("Chill");
  const [details, setDetails] = useState("");
  const [composition, setComposition] = useState(null);
  const [loading, setLoading] = useState(false);

  const compose = async () => {
    setLoading(true);
    setComposition(null);
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Create a detailed music composition description for a ${genre} song with a ${mood} mood. ${details ? `Additional context: ${details}` : ""}
      Return JSON with: bpm (number), key (string), timeSignature (string), chordProgression (string), instruments (array of strings), structure (array of {section, bars, description}), audioVisualization (array of 40 numbers 10-100 representing waveform).`,
      response_json_schema: {
        type: "object",
        properties: {
          bpm: { type: "number" },
          key: { type: "string" },
          timeSignature: { type: "string" },
          chordProgression: { type: "string" },
          instruments: { type: "array", items: { type: "string" } },
          structure: { type: "array", items: { type: "object", properties: { section: {type:"string"}, bars: {type:"number"}, description: {type:"string"} } } },
          audioVisualization: { type: "array", items: { type: "number" } }
        }
      }
    });
    setComposition({ ...res, genre, mood });
    setLoading(false);
  };

  const download = () => {
    const text = composition ? JSON.stringify(composition, null, 2) : "";
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text],{type:"text/plain"})); a.download = "music-composition.txt"; a.click();
  };

  const playPreview = () => {
    if (!composition) return;
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const notes = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.value = freq;
      osc.type = "sine";
      gain.gain.setValueAtTime(0, ctx.currentTime + i * 0.3);
      gain.gain.linearRampToValueAtTime(0.15, ctx.currentTime + i * 0.3 + 0.05);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + i * 0.3 + 0.25);
      osc.start(ctx.currentTime + i * 0.3);
      osc.stop(ctx.currentTime + i * 0.3 + 0.3);
    });
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div className="mb-4">
            <label className="block text-sm font-medium text-foreground mb-2">Genre</label>
            <div className="flex flex-wrap gap-2">
              {GENRES.map(g => <button key={g} onClick={() => setGenre(g)} className={`px-3 py-1.5 rounded-full text-xs font-medium ${genre===g?"bg-fuchsia-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>{g}</button>)}
            </div>
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-foreground mb-2">Mood</label>
            <div className="flex flex-wrap gap-2">
              {MOODS.map(m => <button key={m} onClick={() => setMood(m)} className={`px-3 py-1.5 rounded-full text-xs font-medium ${mood===m?"bg-pink-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>{m}</button>)}
            </div>
          </div>
          <textarea value={details} onChange={e => setDetails(e.target.value)} rows={2} placeholder="Additional details (optional)..." className="w-full px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-fuchsia-400 resize-none mb-4" />

          <button onClick={compose} disabled={loading} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-fuchsia-500 to-pink-500 text-white text-sm font-semibold disabled:opacity-40 mb-4">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Music className="w-4 h-4" />}
            {loading ? "Composing..." : "Compose"}
          </button>

          {composition && (
            <>
              <div className="flex flex-wrap gap-2 mb-3">
                <button onClick={playPreview} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-pink-600 text-white text-xs">▶ Preview Sound</button>
                <button onClick={() => navigator.clipboard.writeText(JSON.stringify(composition,null,2))} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs"><Copy className="w-3.5 h-3.5" /> Copy</button>
                <button onClick={download} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-fuchsia-600 text-white text-xs"><Download className="w-3.5 h-3.5" /> Download</button>
              </div>

              <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-5">
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="bg-slate-800 text-white rounded-xl p-3 text-center">
                    <div className="text-2xl font-bold">{composition.bpm}</div>
                    <div className="text-xs text-slate-400 mt-1">BPM</div>
                  </div>
                  <div className="bg-teal-700 text-white rounded-xl p-3 text-center">
                    <div className="text-lg font-bold">{composition.genre}</div>
                    <div className="text-xs text-teal-200 mt-1">GENRE</div>
                  </div>
                  <div className="bg-teal-600 text-white rounded-xl p-3 text-center">
                    <div className="text-lg font-bold">{composition.mood}</div>
                    <div className="text-xs text-teal-100 mt-1">MOOD</div>
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Chord Progression</div>
                  <div className="text-sm bg-violet-50 dark:bg-violet-900/20 text-violet-700 dark:text-violet-300 px-3 py-2 rounded-lg">{composition.chordProgression}</div>
                </div>

                <div className="mb-3">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Audio Visualization</div>
                  <div className="flex items-end gap-0.5 h-16">
                    {(composition.audioVisualization || []).map((h, i) => (
                      <div key={i} className="flex-1 rounded-sm bg-pink-400 dark:bg-pink-500 opacity-80" style={{ height: `${Math.min(100, h)}%` }} />
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}