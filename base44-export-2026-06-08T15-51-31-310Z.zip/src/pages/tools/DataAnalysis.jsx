const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useRef } from "react";

import { Loader2, Upload, BarChart2, Download, Copy } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import ApiKeyRequired from "@/components/ApiKeyRequired";

export default function DataAnalysis() {
  const tool = getToolByPath("/data-analysis");
  const [file, setFile] = useState(null);
  const [analysis, setAnalysis] = useState("");
  const [loading, setLoading] = useState(false);
  const fileRef = useRef();

  const handleFile = (e) => {
    const f = e.target.files[0];
    if (f) setFile(f);
  };

  const analyze = async () => {
    if (!file || loading) return;
    setLoading(true);
    setAnalysis("");
    const text = await file.text();
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Analyze this CSV/data file and provide detailed insights:\n\n${text.slice(0, 5000)}\n\nProvide:
1. Summary Statistics (row count, columns, data types)
2. Key Insights (patterns, trends, anomalies)
3. Data Quality observations
4. Recommendations for using this data
Be thorough and structured.`,
    });
    setAnalysis(res);
    setLoading(false);
  };

  const download = () => {
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([analysis],{type:"text/plain"})); a.download = "analysis.txt"; a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed border-border rounded-2xl p-10 text-center cursor-pointer hover:border-orange-400 hover:bg-orange-50/50 dark:hover:bg-orange-900/10 transition-colors mb-4"
          >
            <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <p className="font-medium text-foreground text-sm">{file ? file.name : "Click to upload CSV"}</p>
            <p className="text-xs text-muted-foreground mt-1">Supports CSV, TSV, and text files</p>
            <input ref={fileRef} type="file" accept=".csv,.tsv,.txt" onChange={handleFile} className="hidden" />
          </div>

          {file && (
            <button onClick={analyze} disabled={loading} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 text-white text-sm font-semibold disabled:opacity-40 mb-6">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart2 className="w-4 h-4" />}
              {loading ? "Analyzing..." : "Analyze Data"}
            </button>
          )}

          {analysis && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border overflow-hidden">
              <div className="flex justify-end gap-2 p-3 border-b border-border flex-wrap">
                <SaveToProjectButton tool="Data Analysis" title={`Analysis: ${file?.name || "data"}`} content={analysis} />
                <button onClick={() => navigator.clipboard.writeText(analysis)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs"><Copy className="w-3.5 h-3.5" /> Copy</button>
                <button onClick={download} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500 text-white text-xs"><Download className="w-3.5 h-3.5" /> Download</button>
              </div>
              <div className="p-5 prose-output text-sm text-foreground leading-relaxed">
                <ReactMarkdown>{analysis}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}