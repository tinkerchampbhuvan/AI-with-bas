const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, ChevronLeft, ChevronRight, Download, Copy, Presentation } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ApiKeyRequired from "@/components/ApiKeyRequired";

export default function Presentations() {
  const tool = getToolByPath("/presentations");
  const [prompt, setPrompt] = useState("");
  const [slides, setSlides] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [view, setView] = useState("preview");
  const [rawMd, setRawMd] = useState("");

  const create = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setSlides([]);
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Create a professional presentation on: "${prompt}". 
      Return a JSON array of 8 slides. Each slide: {title: string, bullets: string[], theme: string (one of: "dark-blue","purple","teal","orange","green")}.
      Return ONLY valid JSON array.`,
      response_json_schema: {
        type: "object",
        properties: {
          slides: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                bullets: { type: "array", items: { type: "string" } },
                theme: { type: "string" }
              }
            }
          }
        }
      }
    });
    setSlides(res.slides || []);
    setRawMd(res.slides?.map((s, i) => `## Slide ${i+1}: ${s.title}\n${s.bullets.map(b => `- ${b}`).join("\n")}`).join("\n\n") || "");
    setCurrentSlide(0);
    setLoading(false);
  };

  const themeColors = {
    "dark-blue": "from-blue-900 to-indigo-900",
    "purple": "from-purple-800 to-violet-900",
    "teal": "from-teal-700 to-cyan-900",
    "orange": "from-orange-600 to-red-800",
    "green": "from-green-700 to-emerald-900",
  };

  const downloadHtml = () => {
    const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:sans-serif;margin:0;background:#0f172a;display:flex;flex-direction:column;align-items:center;padding:2rem;}
.slide{background:linear-gradient(135deg,#1e3a8a,#312e81);color:white;width:800px;min-height:400px;border-radius:16px;padding:3rem;margin:1rem 0;}
h2{font-size:2rem;margin-bottom:1.5rem;}ul{font-size:1.1rem;line-height:2;}
</style></head><body>${slides.map((s,i)=>`<div class="slide"><h2>${s.title}</h2><ul>${s.bullets.map(b=>`<li>${b}</li>`).join("")}</ul></div>`).join("")}</body></html>`;
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([html],{type:"text/html"})); a.download = "presentation.html"; a.click();
  };

  const slide = slides[currentSlide];

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 mb-4">
            <input value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => e.key === "Enter" && create()}
              placeholder="AI and use in real life..."
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400" />
            <button onClick={create} disabled={!prompt.trim() || loading} className="px-5 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-green-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Create
            </button>
          </div>

          {slides.length > 0 && (
            <>
              <div className="flex flex-wrap gap-2 mb-3">
                {["preview","markdown"].map(v => (
                  <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${view===v?"bg-violet-600 text-white":"bg-white dark:bg-slate-800 border border-border"}`}>
                    {v === "preview" ? "Slide Preview" : "Markdown"}
                  </button>
                ))}
                <button onClick={() => { const w = window.open(); w.document.write(`<!DOCTYPE html><html><head><style>body{margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh;}.slide{color:white;padding:4rem;border-radius:16px;max-width:900px;width:100%;}</style></head><body><div class="slide" style="background:linear-gradient(135deg,#1e3a8a,#312e81)"><h1 style="font-size:2.5rem;margin-bottom:2rem">${slides[0].title}</h1><ul style="font-size:1.2rem;line-height:2.2">${slides[0].bullets.map(b=>`<li>${b}</li>`).join("")}</ul></div></body></html>`); }} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5">
                  <Presentation className="w-3.5 h-3.5" /> Present
                </button>
                <button onClick={() => navigator.clipboard.writeText(rawMd)} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-slate-800 border border-border flex items-center gap-1.5">
                  <Copy className="w-3.5 h-3.5" /> Copy
                </button>
                <button onClick={downloadHtml} className="px-3 py-1.5 rounded-lg text-xs font-medium bg-teal-600 text-white flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5" /> .html
                </button>
              </div>

              {view === "preview" && slide && (
                <div>
                  <div className={`bg-gradient-to-br ${themeColors[slide.theme] || "from-blue-900 to-indigo-900"} text-white rounded-2xl p-8 min-h-[260px]`}>
                    <div className="text-xs text-white/50 mb-2">{currentSlide+1}/{slides.length}</div>
                    <h2 className="text-2xl font-bold mb-4">{slide.title}</h2>
                    <ul className="space-y-2">
                      {slide.bullets.map((b, i) => <li key={i} className="flex items-start gap-2 text-white/90"><span className="mt-1 w-1.5 h-1.5 rounded-full bg-white/60 shrink-0" />{b}</li>)}
                    </ul>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <button onClick={() => setCurrentSlide(Math.max(0, currentSlide-1))} disabled={currentSlide===0} className="p-2 rounded-lg border border-border disabled:opacity-30"><ChevronLeft className="w-4 h-4" /></button>
                    <div className="flex gap-1">
                      {slides.map((_, i) => (
                        <button key={i} onClick={() => setCurrentSlide(i)} className={`w-2 h-2 rounded-full transition-all ${i===currentSlide?"bg-violet-600 w-6":"bg-slate-300"}`} />
                      ))}
                    </div>
                    <button onClick={() => setCurrentSlide(Math.min(slides.length-1, currentSlide+1))} disabled={currentSlide===slides.length-1} className="p-2 rounded-lg border border-border disabled:opacity-30"><ChevronRight className="w-4 h-4" /></button>
                  </div>
                  <div className="flex gap-2 mt-3 overflow-x-auto py-1">
                    {slides.map((s, i) => (
                      <button key={i} onClick={() => setCurrentSlide(i)} className={`shrink-0 w-28 p-2 rounded-lg text-xs text-left border ${i===currentSlide?"border-violet-500 bg-violet-50 dark:bg-violet-900/20":"border-border bg-white dark:bg-slate-800"}`}>
                        <div className="font-semibold text-xs truncate">{i+1}. {s.title}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {view === "markdown" && <pre className="bg-white dark:bg-slate-800 border border-border rounded-xl p-4 text-xs overflow-x-auto whitespace-pre-wrap">{rawMd}</pre>}
            </>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}