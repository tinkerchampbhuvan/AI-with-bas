import { useState, useEffect, useRef } from "react";
import { Download } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";

export default function QrGenerator() {
  const tool = getToolByPath("/qr-generator");
  const [content, setContent] = useState("");
  const [size, setSize] = useState(256);
  const [fg, setFg] = useState("#000000");
  const [bg, setBg] = useState("#ffffff");
  const [qrUrl, setQrUrl] = useState("");

  useEffect(() => {
    if (content.trim()) {
      const encoded = encodeURIComponent(content);
      const fgHex = fg.replace("#", "");
      const bgHex = bg.replace("#", "");
      setQrUrl(`https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encoded}&color=${fgHex}&bgcolor=${bgHex}`);
    } else {
      setQrUrl("");
    }
  }, [content, size, fg, bg]);

  const download = () => {
    const a = document.createElement("a");
    a.href = qrUrl;
    a.download = "qrcode.png";
    a.target = "_blank";
    a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-2xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-foreground mb-2">Content (URL or text)</label>
                <textarea value={content} onChange={e => setContent(e.target.value)} rows={3}
                  placeholder="https://aim.gov.in..."
                  className="w-full px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-none" />
              </div>

              <div className="grid grid-cols-3 gap-3 mb-4">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Size</label>
                  <input type="number" value={size} onChange={e => setSize(Math.min(512, Math.max(64, Number(e.target.value))))}
                    className="w-full px-3 py-2 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Foreground</label>
                  <input type="color" value={fg} onChange={e => setFg(e.target.value)}
                    className="w-full h-10 rounded-xl border border-border cursor-pointer" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">Background</label>
                  <input type="color" value={bg} onChange={e => setBg(e.target.value)}
                    className="w-full h-10 rounded-xl border border-border cursor-pointer" />
                </div>
              </div>

              {qrUrl && (
                <button onClick={download} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-blue-500 text-white text-sm font-semibold">
                  <Download className="w-4 h-4" /> Download PNG
                </button>
              )}
            </div>

            <div className="flex items-center justify-center">
              {qrUrl ? (
                <div className="bg-white p-4 rounded-2xl border border-border shadow-sm">
                  <img src={qrUrl} alt="QR Code" width={size} height={size} className="block" />
                </div>
              ) : (
                <div className="w-48 h-48 bg-white dark:bg-slate-800 rounded-2xl border-2 border-dashed border-border flex items-center justify-center">
                  <p className="text-xs text-muted-foreground text-center px-4">Enter content to generate QR code</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}