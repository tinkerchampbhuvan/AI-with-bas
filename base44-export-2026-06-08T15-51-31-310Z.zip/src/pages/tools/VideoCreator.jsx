const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Loader2, Download, Copy } from "lucide-react";
import ToolHeader from "@/components/layout/ToolHeader";
import { getToolByPath } from "@/lib/tools";
import ReactMarkdown from "react-markdown";
import SaveToProjectButton from "@/components/projects/SaveToProjectButton";
import ApiKeyRequired from "@/components/ApiKeyRequired";

export default function VideoCreator() {
  const tool = getToolByPath("/video-creator");
  const [prompt, setPrompt] = useState("");
  const [script, setScript] = useState("");
  const [loading, setLoading] = useState(false);

  const create = async () => {
    if (!prompt.trim() || loading) return;
    setLoading(true);
    setScript("");
    const res = await db.integrations.Core.InvokeLLM({
      prompt: `Create a detailed professional video script for: "${prompt}".
      Include: Title, Total Runtime, Music Mood, and multiple SCENES.
      Each scene should have: Time, Visual/Camera Direction, Narration.
      Format it clearly with headers and structured sections. Be very detailed and cinematic.`,
    });
    setScript(res);
    setLoading(false);
  };

  const download = () => {
    const blob = new Blob([script], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "video-script.txt";
    a.click();
  };

  return (
    <div className="flex flex-col h-screen">
      <ToolHeader tool={tool} />
      <ApiKeyRequired>
      <div className="flex-1 overflow-y-auto scrollbar-thin tool-page-bg p-6">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-2 mb-6">
            <input value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => e.key === "Enter" && create()}
              placeholder="Make a video on AI..."
              className="flex-1 px-4 py-3 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
            <button onClick={create} disabled={!prompt.trim() || loading} className="px-5 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Create
            </button>
          </div>

          {script && (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-6">
              <div className="flex justify-end gap-2 mb-4 flex-wrap">
                <SaveToProjectButton tool="Video Creator" title={`Script: ${prompt.slice(0,50)}`} content={script} />
                <button onClick={() => navigator.clipboard.writeText(script)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs hover:bg-slate-50 dark:hover:bg-slate-700">
                  <Copy className="w-3.5 h-3.5" /> Copy
                </button>
                <button onClick={download} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500 text-white text-xs">
                  <Download className="w-3.5 h-3.5" /> Download
                </button>
              </div>
              <div className="prose-output text-sm text-foreground leading-relaxed">
                <ReactMarkdown>{script}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
      </ApiKeyRequired>
    </div>
  );
}