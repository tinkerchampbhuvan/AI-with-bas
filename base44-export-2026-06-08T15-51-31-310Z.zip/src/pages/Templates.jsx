const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BookOpen, Star, Trash2, Edit2, Copy, Check, Plus, Search, Filter } from "lucide-react";
import { Link } from "react-router-dom";

const TOOLS = ["All", "AI Chat", "Code Generator", "Image Creator", "Letter Writer", "Website Builder", "Presentations", "Video Creator", "Voice Generator", "Data Analysis", "Productivity", "Any"];
const CATEGORIES = ["All", "Marketing", "Development", "Education", "Creative", "Business", "Personal", "Research", "Other"];

export default function Templates() {
  const [filterTool, setFilterTool] = useState("All");
  const [filterCat, setFilterCat] = useState("All");
  const [search, setSearch] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({});
  const [copiedId, setCopiedId] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newTemplate, setNewTemplate] = useState({ title: "", prompt: "", tool: "AI Chat", category: "Other", description: "" });
  const qc = useQueryClient();

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ["prompt-templates-all"],
    queryFn: () => db.entities.PromptTemplate.list("-created_date", 100),
  });

  const filtered = templates.filter(t => {
    const toolMatch = filterTool === "All" || t.tool === filterTool;
    const catMatch = filterCat === "All" || t.category === filterCat;
    const searchMatch = !search || t.title.toLowerCase().includes(search.toLowerCase()) || t.prompt.toLowerCase().includes(search.toLowerCase());
    return toolMatch && catMatch && searchMatch;
  });

  const toggleFavorite = async (t) => {
    await db.entities.PromptTemplate.update(t.id, { is_favorite: !t.is_favorite });
    qc.invalidateQueries({ queryKey: ["prompt-templates-all"] });
  };

  const deleteTemplate = async (id) => {
    await db.entities.PromptTemplate.delete(id);
    qc.invalidateQueries({ queryKey: ["prompt-templates-all"] });
  };

  const saveEdit = async () => {
    await db.entities.PromptTemplate.update(editingId, editData);
    qc.invalidateQueries({ queryKey: ["prompt-templates-all"] });
    setEditingId(null);
  };

  const copyPrompt = (id, prompt) => {
    navigator.clipboard.writeText(prompt);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const createTemplate = async () => {
    if (!newTemplate.title.trim() || !newTemplate.prompt.trim()) return;
    await db.entities.PromptTemplate.create({ ...newTemplate, use_count: 0, is_favorite: false });
    qc.invalidateQueries({ queryKey: ["prompt-templates-all"] });
    setShowCreate(false);
    setNewTemplate({ title: "", prompt: "", tool: "AI Chat", category: "Other", description: "" });
  };

  const toolColors = {
    "AI Chat": "bg-violet-100 text-violet-700",
    "Code Generator": "bg-cyan-100 text-cyan-700",
    "Image Creator": "bg-pink-100 text-pink-700",
    "Letter Writer": "bg-green-100 text-green-700",
    "Website Builder": "bg-blue-100 text-blue-700",
    "Presentations": "bg-teal-100 text-teal-700",
    "Video Creator": "bg-orange-100 text-orange-700",
    "Voice Generator": "bg-purple-100 text-purple-700",
    "Data Analysis": "bg-amber-100 text-amber-700",
    "Productivity": "bg-lime-100 text-lime-700",
    "Any": "bg-slate-100 text-slate-600",
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-violet-500" />
            Prompt Templates
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Save, manage, and reuse your best AI prompts across all tools.</p>
        </div>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-600 text-white text-sm font-semibold hover:bg-violet-700 transition-colors"
        >
          <Plus className="w-4 h-4" /> New Template
        </button>
      </div>

      {/* Create Form */}
      {showCreate && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-violet-200 p-5 mb-6 shadow-sm">
          <h2 className="font-semibold text-sm mb-4">Create New Template</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
            <input value={newTemplate.title} onChange={e => setNewTemplate(p => ({...p, title: e.target.value}))}
              placeholder="Template title..." className="px-3 py-2 rounded-lg border border-border text-sm bg-slate-50 dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-violet-400" />
            <input value={newTemplate.description} onChange={e => setNewTemplate(p => ({...p, description: e.target.value}))}
              placeholder="Short description..." className="px-3 py-2 rounded-lg border border-border text-sm bg-slate-50 dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-violet-400" />
            <select value={newTemplate.tool} onChange={e => setNewTemplate(p => ({...p, tool: e.target.value}))}
              className="px-3 py-2 rounded-lg border border-border text-sm bg-slate-50 dark:bg-slate-700 focus:outline-none">
              {TOOLS.filter(t => t !== "All").map(t => <option key={t}>{t}</option>)}
            </select>
            <select value={newTemplate.category} onChange={e => setNewTemplate(p => ({...p, category: e.target.value}))}
              className="px-3 py-2 rounded-lg border border-border text-sm bg-slate-50 dark:bg-slate-700 focus:outline-none">
              {CATEGORIES.filter(c => c !== "All").map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <textarea value={newTemplate.prompt} onChange={e => setNewTemplate(p => ({...p, prompt: e.target.value}))}
            placeholder="Enter your reusable prompt..." rows={4}
            className="w-full px-3 py-2 rounded-lg border border-border text-sm bg-slate-50 dark:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-violet-400 resize-none mb-3" />
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowCreate(false)} className="px-4 py-2 rounded-lg border border-border text-sm">Cancel</button>
            <button onClick={createTemplate} disabled={!newTemplate.title.trim() || !newTemplate.prompt.trim()}
              className="px-4 py-2 rounded-lg bg-violet-600 text-white text-sm font-semibold disabled:opacity-40">Save Template</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 rounded-xl border border-border px-3 py-2 flex-1 min-w-48">
          <Search className="w-3.5 h-3.5 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search templates..." className="bg-transparent text-sm focus:outline-none flex-1" />
        </div>
        <select value={filterTool} onChange={e => setFilterTool(e.target.value)}
          className="px-3 py-2 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none">
          {TOOLS.map(t => <option key={t}>{t}</option>)}
        </select>
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)}
          className="px-3 py-2 rounded-xl border border-border bg-white dark:bg-slate-800 text-sm focus:outline-none">
          {CATEGORIES.map(c => <option key={c}>{c}</option>)}
        </select>
      </div>

      {/* Stats bar */}
      <div className="flex gap-4 text-xs text-muted-foreground mb-4">
        <span>{templates.length} total templates</span>
        <span>{templates.filter(t => t.is_favorite).length} favorites</span>
        <span>{filtered.length} shown</span>
      </div>

      {/* Template Grid */}
      {isLoading ? (
        <div className="text-center py-16 text-muted-foreground text-sm">Loading templates…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium text-foreground mb-1">No templates found</p>
          <p className="text-xs text-muted-foreground">Create your first template or save prompts from any tool.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filtered.map(t => (
            <div key={t.id} className="bg-white dark:bg-slate-800 rounded-2xl border-2 border-border hover:border-violet-200 transition-all p-4">
              {editingId === t.id ? (
                <div className="space-y-2">
                  <input value={editData.title} onChange={e => setEditData(p => ({...p, title: e.target.value}))}
                    className="w-full px-2 py-1.5 rounded-lg border border-border text-sm focus:outline-none" />
                  <input value={editData.description || ""} onChange={e => setEditData(p => ({...p, description: e.target.value}))}
                    placeholder="Description..." className="w-full px-2 py-1.5 rounded-lg border border-border text-xs focus:outline-none" />
                  <textarea value={editData.prompt} onChange={e => setEditData(p => ({...p, prompt: e.target.value}))}
                    rows={3} className="w-full px-2 py-1.5 rounded-lg border border-border text-xs resize-none focus:outline-none" />
                  <div className="flex gap-2">
                    <button onClick={saveEdit} className="flex-1 py-1.5 rounded-lg bg-violet-600 text-white text-xs font-semibold">Save</button>
                    <button onClick={() => setEditingId(null)} className="flex-1 py-1.5 rounded-lg border border-border text-xs">Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="font-semibold text-sm text-foreground truncate">{t.title}</h3>
                        {t.is_favorite && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400 shrink-0" />}
                      </div>
                      <div className="flex gap-1.5 flex-wrap mb-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${toolColors[t.tool] || "bg-slate-100 text-slate-600"}`}>{t.tool}</span>
                        {t.category && <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700 text-muted-foreground">{t.category}</span>}
                      </div>
                      {t.description && <p className="text-xs text-muted-foreground">{t.description}</p>}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground bg-slate-50 dark:bg-slate-700 rounded-lg p-2.5 mb-3 line-clamp-3 leading-relaxed">{t.prompt}</p>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button onClick={() => copyPrompt(t.id, t.prompt)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-violet-600 text-white text-xs font-medium">
                      {copiedId === t.id ? <><Check className="w-3 h-3" /> Copied!</> : <><Copy className="w-3 h-3" /> Use Prompt</>}
                    </button>
                    <button onClick={() => toggleFavorite(t)}
                      className={`p-1.5 rounded-lg border border-border text-xs ${t.is_favorite ? "text-amber-400" : "text-muted-foreground"}`}>
                      <Star className={`w-3.5 h-3.5 ${t.is_favorite ? "fill-amber-400" : ""}`} />
                    </button>
                    <button onClick={() => { setEditingId(t.id); setEditData({ title: t.title, prompt: t.prompt, description: t.description || "" }); }}
                      className="p-1.5 rounded-lg border border-border text-muted-foreground hover:text-foreground">
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => deleteTemplate(t.id)}
                      className="p-1.5 rounded-lg border border-border text-muted-foreground hover:text-red-500">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {t.use_count > 0 && (
                      <span className="ml-auto text-xs text-muted-foreground">Used {t.use_count}×</span>
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}